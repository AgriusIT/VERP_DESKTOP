<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmPaymentNew
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim grd_DesignTimeLayout As Janus.Windows.GridEX.GridEXLayout = New Janus.Windows.GridEX.GridEXLayout()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmPaymentNew))
        Dim Appearance13 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance7 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance8 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim UltraGridBand2 As Infragistics.Win.UltraWinGrid.UltraGridBand = New Infragistics.Win.UltraWinGrid.UltraGridBand("Band 0", -1)
        Dim UltraGridColumn7 As Infragistics.Win.UltraWinGrid.UltraGridColumn = New Infragistics.Win.UltraWinGrid.UltraGridColumn("ID")
        Dim UltraGridColumn8 As Infragistics.Win.UltraWinGrid.UltraGridColumn = New Infragistics.Win.UltraWinGrid.UltraGridColumn("Name")
        Dim UltraGridColumn9 As Infragistics.Win.UltraWinGrid.UltraGridColumn = New Infragistics.Win.UltraWinGrid.UltraGridColumn("Territory")
        Dim UltraGridColumn10 As Infragistics.Win.UltraWinGrid.UltraGridColumn = New Infragistics.Win.UltraWinGrid.UltraGridColumn("City")
        Dim UltraGridColumn11 As Infragistics.Win.UltraWinGrid.UltraGridColumn = New Infragistics.Win.UltraWinGrid.UltraGridColumn("State")
        Dim UltraGridColumn12 As Infragistics.Win.UltraWinGrid.UltraGridColumn = New Infragistics.Win.UltraWinGrid.UltraGridColumn("AcId")
        Dim Appearance9 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance10 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance11 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance12 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance14 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance15 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim UltraGridBand3 As Infragistics.Win.UltraWinGrid.UltraGridBand = New Infragistics.Win.UltraWinGrid.UltraGridBand("Band 0", -1)
        Dim UltraGridColumn13 As Infragistics.Win.UltraWinGrid.UltraGridColumn = New Infragistics.Win.UltraWinGrid.UltraGridColumn("ID")
        Dim UltraGridColumn14 As Infragistics.Win.UltraWinGrid.UltraGridColumn = New Infragistics.Win.UltraWinGrid.UltraGridColumn("Name")
        Dim UltraGridColumn15 As Infragistics.Win.UltraWinGrid.UltraGridColumn = New Infragistics.Win.UltraWinGrid.UltraGridColumn("Territory")
        Dim UltraGridColumn16 As Infragistics.Win.UltraWinGrid.UltraGridColumn = New Infragistics.Win.UltraWinGrid.UltraGridColumn("City")
        Dim UltraGridColumn17 As Infragistics.Win.UltraWinGrid.UltraGridColumn = New Infragistics.Win.UltraWinGrid.UltraGridColumn("State")
        Dim UltraGridColumn18 As Infragistics.Win.UltraWinGrid.UltraGridColumn = New Infragistics.Win.UltraWinGrid.UltraGridColumn("AcId")
        Dim Appearance16 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance17 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance18 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance19 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance1 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance2 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim UltraGridBand1 As Infragistics.Win.UltraWinGrid.UltraGridBand = New Infragistics.Win.UltraWinGrid.UltraGridBand("Band 0", -1)
        Dim UltraGridColumn1 As Infragistics.Win.UltraWinGrid.UltraGridColumn = New Infragistics.Win.UltraWinGrid.UltraGridColumn("ID")
        Dim UltraGridColumn2 As Infragistics.Win.UltraWinGrid.UltraGridColumn = New Infragistics.Win.UltraWinGrid.UltraGridColumn("Name")
        Dim UltraGridColumn3 As Infragistics.Win.UltraWinGrid.UltraGridColumn = New Infragistics.Win.UltraWinGrid.UltraGridColumn("Territory")
        Dim UltraGridColumn4 As Infragistics.Win.UltraWinGrid.UltraGridColumn = New Infragistics.Win.UltraWinGrid.UltraGridColumn("City")
        Dim UltraGridColumn5 As Infragistics.Win.UltraWinGrid.UltraGridColumn = New Infragistics.Win.UltraWinGrid.UltraGridColumn("State")
        Dim UltraGridColumn6 As Infragistics.Win.UltraWinGrid.UltraGridColumn = New Infragistics.Win.UltraWinGrid.UltraGridColumn("AcId")
        Dim Appearance3 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance4 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance5 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim Appearance6 As Infragistics.Win.Appearance = New Infragistics.Win.Appearance()
        Dim UltraTab1 As Infragistics.Win.UltraWinTabControl.UltraTab = New Infragistics.Win.UltraWinTabControl.UltraTab()
        Dim UltraTab2 As Infragistics.Win.UltraWinTabControl.UltraTab = New Infragistics.Win.UltraWinTabControl.UltraTab()
        Me.UltraTabPageControl1 = New Infragistics.Win.UltraWinTabControl.UltraTabPageControl()
        Me.CtrlGrdBar4 = New SimpleAccounts.CtrlGrdBar()
        Me.grd = New Janus.Windows.GridEX.GridEX()
        Me.lblPrintStatus = New System.Windows.Forms.Label()
        Me.pnlGrd = New System.Windows.Forms.Panel()
        Me.lblProgress = New System.Windows.Forms.Label()
        Me.pnlDetail = New System.Windows.Forms.Panel()
        Me.pnlHeader = New System.Windows.Forms.Panel()
        Me.lblHeader = New System.Windows.Forms.Label()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.lblCashRequest = New System.Windows.Forms.Label()
        Me.cmbCashRequest = New System.Windows.Forms.ComboBox()
        Me.lblPostedBy = New System.Windows.Forms.Label()
        Me.chkEnableDepositAc = New System.Windows.Forms.CheckBox()
        Me.lblCheckedBy = New System.Windows.Forms.Label()
        Me.txtDepositBeforeBalance = New System.Windows.Forms.TextBox()
        Me.txtCurrencyRate = New System.Windows.Forms.TextBox()
        Me.lblCurrencyRate = New System.Windows.Forms.Label()
        Me.txtMemo = New Infragistics.Win.UltraWinEditors.UltraTextEditor()
        Me.cmbCashAccount = New System.Windows.Forms.ComboBox()
        Me.lblCompany = New System.Windows.Forms.Label()
        Me.cmbVoucherType = New System.Windows.Forms.ComboBox()
        Me.lblDocDate = New System.Windows.Forms.Label()
        Me.dtVoucherDate = New System.Windows.Forms.DateTimePicker()
        Me.chkPost = New System.Windows.Forms.CheckBox()
        Me.chkChecked = New System.Windows.Forms.CheckBox()
        Me.cmbCompany = New System.Windows.Forms.ComboBox()
        Me.cmbCurrency = New System.Windows.Forms.ComboBox()
        Me.lblCurrency = New System.Windows.Forms.Label()
        Me.lblReference = New System.Windows.Forms.Label()
        Me.lblPayMethod = New System.Windows.Forms.Label()
        Me.txtVoucherNo = New System.Windows.Forms.TextBox()
        Me.lblRecieveIn = New System.Windows.Forms.Label()
        Me.lblVoucherNo = New System.Windows.Forms.Label()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.chkAllAccounts = New System.Windows.Forms.CheckBox()
        Me.cmbInvoice = New Infragistics.Win.UltraWinGrid.UltraCombo()
        Me.lblInvoice = New System.Windows.Forms.Label()
        Me.lblNetAmountNumberConvertor = New System.Windows.Forms.Label()
        Me.lblAmountNumberConvertor = New System.Windows.Forms.Label()
        Me.lblPayment = New System.Windows.Forms.Label()
        Me.txtCustomerBalance = New System.Windows.Forms.TextBox()
        Me.txtTax = New System.Windows.Forms.TextBox()
        Me.Label30 = New System.Windows.Forms.Label()
        Me.txtTaxAmount = New System.Windows.Forms.TextBox()
        Me.Label31 = New System.Windows.Forms.Label()
        Me.txtAmount = New System.Windows.Forms.TextBox()
        Me.txtNetAmount = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.txtWithHoldingTaxAmount = New System.Windows.Forms.TextBox()
        Me.lblWH = New System.Windows.Forms.Label()
        Me.txtWithHolding = New System.Windows.Forms.TextBox()
        Me.lblNetAmount = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.txtSalesTaxAmount = New System.Windows.Forms.TextBox()
        Me.cmbAccounts = New Infragistics.Win.UltraWinGrid.UltraCombo()
        Me.txtDiscount = New System.Windows.Forms.TextBox()
        Me.txtSalesTax = New System.Windows.Forms.TextBox()
        Me.Label29 = New System.Windows.Forms.Label()
        Me.lblWHTaxAmount = New System.Windows.Forms.Label()
        Me.lblSalesTax = New System.Windows.Forms.Label()
        Me.lblSalesTaxAmount = New System.Windows.Forms.Label()
        Me.lblGrossAmount = New System.Windows.Forms.Label()
        Me.txtGrossAmount = New System.Windows.Forms.TextBox()
        Me.cmbSalesTax = New System.Windows.Forms.ComboBox()
        Me.lblIncomeTaxAccount = New System.Windows.Forms.Label()
        Me.lblSales = New System.Windows.Forms.Label()
        Me.cmbIncomeTaxAccount = New System.Windows.Forms.ComboBox()
        Me.FlowLayoutPanel1 = New System.Windows.Forms.FlowLayoutPanel()
        Me.pnlBank = New System.Windows.Forms.Panel()
        Me.Label36 = New System.Windows.Forms.Label()
        Me.cmbChequeBook = New System.Windows.Forms.ComboBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.cmbBank = New System.Windows.Forms.ComboBox()
        Me.txtChequeNo = New System.Windows.Forms.TextBox()
        Me.dtChequeDate = New System.Windows.Forms.DateTimePicker()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.pnlCost = New System.Windows.Forms.Panel()
        Me.lblCostCenter = New System.Windows.Forms.Label()
        Me.btnCancel = New System.Windows.Forms.Button()
        Me.btnReplace = New System.Windows.Forms.Button()
        Me.btnAdd = New System.Windows.Forms.Button()
        Me.txtReference = New Infragistics.Win.UltraWinEditors.UltraTextEditor()
        Me.cmbCostCenter = New System.Windows.Forms.ComboBox()
        Me.lblDescription = New System.Windows.Forms.Label()
        Me.lblSaleman = New System.Windows.Forms.Label()
        Me.cmbSaleman = New System.Windows.Forms.ComboBox()
        Me.ToolStrip1 = New System.Windows.Forms.ToolStrip()
        Me.BtnNew = New System.Windows.Forms.ToolStripButton()
        Me.BtnEdit = New System.Windows.Forms.ToolStripButton()
        Me.BtnSave = New System.Windows.Forms.ToolStripButton()
        Me.BtnDelete = New System.Windows.Forms.ToolStripButton()
        Me.BtnPrint = New System.Windows.Forms.ToolStripSplitButton()
        Me.PrintReceiptToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.PrintAttachmentVoucherToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.PrintUpdatedVoucherToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.toolStripSeparator1 = New System.Windows.Forms.ToolStripSeparator()
        Me.btnUpdateTimes = New System.Windows.Forms.ToolStripSplitButton()
        Me.btnReminder = New System.Windows.Forms.ToolStripButton()
        Me.BtnRefresh = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripSeparator3 = New System.Windows.Forms.ToolStripSeparator()
        Me.btnApprovalHistory = New System.Windows.Forms.ToolStripButton()
        Me.btnAttachment = New System.Windows.Forms.ToolStripSplitButton()
        Me.btnPreviewAttachment = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator8 = New System.Windows.Forms.ToolStripSeparator()
        Me.btnSMSTemplate = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripSeparator9 = New System.Windows.Forms.ToolStripSeparator()
        Me.HelpToolStripButton = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripSeparator2 = New System.Windows.Forms.ToolStripSeparator()
        Me.TaxConfiguration = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripSeparator14 = New System.Windows.Forms.ToolStripSeparator()
        Me.btnBackToOldReciept = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripSeparator11 = New System.Windows.Forms.ToolStripSeparator()
        Me.ToolStripButton1 = New System.Windows.Forms.ToolStripButton()
        Me.cmbLayout = New System.Windows.Forms.ToolStripComboBox()
        Me.ToolStripSeparator12 = New System.Windows.Forms.ToolStripSeparator()
        Me.btnPurchaseInvoiceSearch = New System.Windows.Forms.ToolStripButton()
        Me.grdVoucher = New Infragistics.Win.UltraWinTabControl.UltraTabPageControl()
        Me.CtrlGrdBar10 = New SimpleAccounts.CtrlGrdBar()
        Me.grdVouchers = New Janus.Windows.GridEX.GridEX()
        Me.ToolStrip2 = New System.Windows.Forms.ToolStrip()
        Me.btnHisotryEdit = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripSeparator6 = New System.Windows.Forms.ToolStripSeparator()
        Me.btnSearchDelete = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripSeparator7 = New System.Windows.Forms.ToolStripSeparator()
        Me.btnHistoryPrint = New System.Windows.Forms.ToolStripSplitButton()
        Me.PrintReceiptToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.PrintSelectedVouchersToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.PrintAttachmentVoucherToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator10 = New System.Windows.Forms.ToolStripSeparator()
        Me.btnPrintUpdatedVoucher = New System.Windows.Forms.ToolStripButton()
        Me.toolStripSeparator = New System.Windows.Forms.ToolStripSeparator()
        Me.btnHistoryLoadAll = New System.Windows.Forms.ToolStripButton()
        Me.btnHistorySearch = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripSeparator5 = New System.Windows.Forms.ToolStripSeparator()
        Me.btnReminder1 = New System.Windows.Forms.ToolStripButton()
        Me.Btn_SaveAttachment = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripSeparator4 = New System.Windows.Forms.ToolStripSeparator()
        Me.HelpToolStripButton1 = New System.Windows.Forms.ToolStripButton()
        Me.btnGetAllRecord = New System.Windows.Forms.ToolStripButton()
        Me.SplitContainer1 = New System.Windows.Forms.SplitContainer()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.Search = New System.Windows.Forms.Button()
        Me.dtpSearchChequeDate = New System.Windows.Forms.DateTimePicker()
        Me.Label27 = New System.Windows.Forms.Label()
        Me.Label26 = New System.Windows.Forms.Label()
        Me.txtFromAmount = New System.Windows.Forms.TextBox()
        Me.Label25 = New System.Windows.Forms.Label()
        Me.txtToAmount = New System.Windows.Forms.TextBox()
        Me.Label24 = New System.Windows.Forms.Label()
        Me.txtSearchChequeNo = New System.Windows.Forms.TextBox()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.txtSearchComments = New System.Windows.Forms.TextBox()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.txtSearchVoucherNo = New System.Windows.Forms.TextBox()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.cmbSearchAccount = New Infragistics.Win.UltraWinGrid.UltraCombo()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.dtpFrom = New System.Windows.Forms.DateTimePicker()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.dtpTo = New System.Windows.Forms.DateTimePicker()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.cmbSearchVoucherType = New System.Windows.Forms.ComboBox()
        Me.UltraTabControl1 = New Infragistics.Win.UltraWinTabControl.UltraTabControl()
        Me.UltraTabSharedControlsPage1 = New Infragistics.Win.UltraWinTabControl.UltraTabSharedControlsPage()
        Me.BackgroundWorker1 = New System.ComponentModel.BackgroundWorker()
        Me.ToolTip1 = New System.Windows.Forms.ToolTip(Me.components)
        Me.BackgroundWorker2 = New System.ComponentModel.BackgroundWorker()
        Me.OpenFileDialog1 = New System.Windows.Forms.OpenFileDialog()
        Me.UltraTabPageControl1.SuspendLayout()
        CType(Me.grd, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.pnlGrd.SuspendLayout()
        Me.pnlDetail.SuspendLayout()
        Me.pnlHeader.SuspendLayout()
        Me.Panel1.SuspendLayout()
        CType(Me.txtMemo, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel2.SuspendLayout()
        CType(Me.cmbInvoice, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.cmbAccounts, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.FlowLayoutPanel1.SuspendLayout()
        Me.pnlBank.SuspendLayout()
        Me.pnlCost.SuspendLayout()
        CType(Me.txtReference, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.ToolStrip1.SuspendLayout()
        Me.grdVoucher.SuspendLayout()
        CType(Me.grdVouchers, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.ToolStrip2.SuspendLayout()
        CType(Me.SplitContainer1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SplitContainer1.Panel1.SuspendLayout()
        Me.SplitContainer1.Panel2.SuspendLayout()
        Me.SplitContainer1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        CType(Me.cmbSearchAccount, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.UltraTabControl1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.UltraTabControl1.SuspendLayout()
        Me.SuspendLayout()
        '
        'UltraTabPageControl1
        '
        Me.UltraTabPageControl1.Controls.Add(Me.CtrlGrdBar4)
        Me.UltraTabPageControl1.Controls.Add(Me.lblPrintStatus)
        Me.UltraTabPageControl1.Controls.Add(Me.pnlGrd)
        Me.UltraTabPageControl1.Controls.Add(Me.pnlDetail)
        Me.UltraTabPageControl1.Controls.Add(Me.ToolStrip1)
        Me.UltraTabPageControl1.Location = New System.Drawing.Point(1, 1)
        Me.UltraTabPageControl1.Name = "UltraTabPageControl1"
        Me.UltraTabPageControl1.Size = New System.Drawing.Size(1282, 668)
        '
        'CtrlGrdBar4
        '
        Me.CtrlGrdBar4.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.CtrlGrdBar4.BackColor = System.Drawing.Color.Transparent
        Me.CtrlGrdBar4.Email = Nothing
        Me.CtrlGrdBar4.FormName = Me
        Me.CtrlGrdBar4.Location = New System.Drawing.Point(1248, -1)
        Me.CtrlGrdBar4.MyGrid = Me.grd
        Me.CtrlGrdBar4.Name = "CtrlGrdBar4"
        Me.CtrlGrdBar4.Size = New System.Drawing.Size(38, 25)
        Me.CtrlGrdBar4.TabIndex = 2
        Me.CtrlGrdBar4.TabStop = False
        '
        'grd
        '
        Me.grd.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        grd_DesignTimeLayout.LayoutString = resources.GetString("grd_DesignTimeLayout.LayoutString")
        Me.grd.DesignTimeLayout = grd_DesignTimeLayout
        Me.grd.Font = New System.Drawing.Font("Verdana", 8.25!)
        Me.grd.GroupByBoxVisible = False
        Me.grd.Location = New System.Drawing.Point(0, 4)
        Me.grd.Name = "grd"
        Me.grd.RecordNavigator = True
        Me.grd.Size = New System.Drawing.Size(1285, 206)
        Me.grd.TabIndex = 0
        Me.grd.TabKeyBehavior = Janus.Windows.GridEX.TabKeyBehavior.ControlNavigation
        Me.grd.TabStop = False
        Me.ToolTip1.SetToolTip(Me.grd, "Receipt Detail")
        Me.grd.TotalRow = Janus.Windows.GridEX.InheritableBoolean.[True]
        Me.grd.TotalRowPosition = Janus.Windows.GridEX.TotalRowPosition.BottomFixed
        Me.grd.VisualStyle = Janus.Windows.GridEX.VisualStyle.Office2007
        '
        'lblPrintStatus
        '
        Me.lblPrintStatus.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lblPrintStatus.AutoSize = True
        Me.lblPrintStatus.Location = New System.Drawing.Point(1113, 36)
        Me.lblPrintStatus.Name = "lblPrintStatus"
        Me.lblPrintStatus.Size = New System.Drawing.Size(161, 13)
        Me.lblPrintStatus.TabIndex = 3
        Me.lblPrintStatus.Text = "Print Status : Print Pending"
        '
        'pnlGrd
        '
        Me.pnlGrd.Controls.Add(Me.lblProgress)
        Me.pnlGrd.Controls.Add(Me.grd)
        Me.pnlGrd.Dock = System.Windows.Forms.DockStyle.Fill
        Me.pnlGrd.Location = New System.Drawing.Point(0, 458)
        Me.pnlGrd.Name = "pnlGrd"
        Me.pnlGrd.Size = New System.Drawing.Size(1282, 210)
        Me.pnlGrd.TabIndex = 2
        '
        'lblProgress
        '
        Me.lblProgress.BackColor = System.Drawing.Color.LightYellow
        Me.lblProgress.ForeColor = System.Drawing.Color.Navy
        Me.lblProgress.Location = New System.Drawing.Point(380, 38)
        Me.lblProgress.Name = "lblProgress"
        Me.lblProgress.Size = New System.Drawing.Size(263, 45)
        Me.lblProgress.TabIndex = 49
        Me.lblProgress.Text = "Processing please wait ..."
        Me.lblProgress.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.lblProgress.Visible = False
        '
        'pnlDetail
        '
        Me.pnlDetail.AutoScroll = True
        Me.pnlDetail.Controls.Add(Me.pnlHeader)
        Me.pnlDetail.Controls.Add(Me.Panel1)
        Me.pnlDetail.Controls.Add(Me.Panel2)
        Me.pnlDetail.Dock = System.Windows.Forms.DockStyle.Top
        Me.pnlDetail.Location = New System.Drawing.Point(0, 25)
        Me.pnlDetail.Name = "pnlDetail"
        Me.pnlDetail.Size = New System.Drawing.Size(1282, 433)
        Me.pnlDetail.TabIndex = 1
        '
        'pnlHeader
        '
        Me.pnlHeader.Controls.Add(Me.lblHeader)
        Me.pnlHeader.Dock = System.Windows.Forms.DockStyle.Top
        Me.pnlHeader.Location = New System.Drawing.Point(0, 0)
        Me.pnlHeader.Name = "pnlHeader"
        Me.pnlHeader.Size = New System.Drawing.Size(1282, 33)
        Me.pnlHeader.TabIndex = 6
        '
        'lblHeader
        '
        Me.lblHeader.AutoSize = True
        Me.lblHeader.Font = New System.Drawing.Font("Verdana", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblHeader.ForeColor = System.Drawing.Color.Navy
        Me.lblHeader.Location = New System.Drawing.Point(15, 5)
        Me.lblHeader.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblHeader.Name = "lblHeader"
        Me.lblHeader.Size = New System.Drawing.Size(105, 23)
        Me.lblHeader.TabIndex = 0
        Me.lblHeader.Text = "Payment"
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(235, Byte), Integer), CType(CType(247, Byte), Integer))
        Me.Panel1.Controls.Add(Me.lblCashRequest)
        Me.Panel1.Controls.Add(Me.cmbCashRequest)
        Me.Panel1.Controls.Add(Me.lblPostedBy)
        Me.Panel1.Controls.Add(Me.chkEnableDepositAc)
        Me.Panel1.Controls.Add(Me.lblCheckedBy)
        Me.Panel1.Controls.Add(Me.txtDepositBeforeBalance)
        Me.Panel1.Controls.Add(Me.txtCurrencyRate)
        Me.Panel1.Controls.Add(Me.lblCurrencyRate)
        Me.Panel1.Controls.Add(Me.txtMemo)
        Me.Panel1.Controls.Add(Me.cmbCashAccount)
        Me.Panel1.Controls.Add(Me.lblCompany)
        Me.Panel1.Controls.Add(Me.cmbVoucherType)
        Me.Panel1.Controls.Add(Me.lblDocDate)
        Me.Panel1.Controls.Add(Me.dtVoucherDate)
        Me.Panel1.Controls.Add(Me.chkPost)
        Me.Panel1.Controls.Add(Me.chkChecked)
        Me.Panel1.Controls.Add(Me.cmbCompany)
        Me.Panel1.Controls.Add(Me.cmbCurrency)
        Me.Panel1.Controls.Add(Me.lblCurrency)
        Me.Panel1.Controls.Add(Me.lblReference)
        Me.Panel1.Controls.Add(Me.lblPayMethod)
        Me.Panel1.Controls.Add(Me.txtVoucherNo)
        Me.Panel1.Controls.Add(Me.lblRecieveIn)
        Me.Panel1.Controls.Add(Me.lblVoucherNo)
        Me.Panel1.Location = New System.Drawing.Point(3, 37)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(943, 105)
        Me.Panel1.TabIndex = 1
        '
        'lblCashRequest
        '
        Me.lblCashRequest.AutoSize = True
        Me.lblCashRequest.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblCashRequest.Location = New System.Drawing.Point(490, 45)
        Me.lblCashRequest.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblCashRequest.Name = "lblCashRequest"
        Me.lblCashRequest.Size = New System.Drawing.Size(86, 13)
        Me.lblCashRequest.TabIndex = 65
        Me.lblCashRequest.Text = "Cash Request"
        '
        'cmbCashRequest
        '
        Me.cmbCashRequest.FormattingEnabled = True
        Me.cmbCashRequest.Location = New System.Drawing.Point(495, 60)
        Me.cmbCashRequest.Name = "cmbCashRequest"
        Me.cmbCashRequest.Size = New System.Drawing.Size(167, 21)
        Me.cmbCashRequest.TabIndex = 66
        '
        'lblPostedBy
        '
        Me.lblPostedBy.AutoSize = True
        Me.lblPostedBy.Location = New System.Drawing.Point(334, 86)
        Me.lblPostedBy.Name = "lblPostedBy"
        Me.lblPostedBy.Size = New System.Drawing.Size(14, 13)
        Me.lblPostedBy.TabIndex = 64
        Me.lblPostedBy.Text = "p"
        '
        'chkEnableDepositAc
        '
        Me.chkEnableDepositAc.AutoSize = True
        Me.chkEnableDepositAc.Location = New System.Drawing.Point(691, 23)
        Me.chkEnableDepositAc.Name = "chkEnableDepositAc"
        Me.chkEnableDepositAc.Size = New System.Drawing.Size(71, 17)
        Me.chkEnableDepositAc.TabIndex = 5
        Me.chkEnableDepositAc.TabStop = False
        Me.chkEnableDepositAc.Text = "Enabled"
        Me.chkEnableDepositAc.UseVisualStyleBackColor = True
        Me.chkEnableDepositAc.Visible = False
        '
        'lblCheckedBy
        '
        Me.lblCheckedBy.AutoSize = True
        Me.lblCheckedBy.Location = New System.Drawing.Point(100, 86)
        Me.lblCheckedBy.Name = "lblCheckedBy"
        Me.lblCheckedBy.Size = New System.Drawing.Size(13, 13)
        Me.lblCheckedBy.TabIndex = 63
        Me.lblCheckedBy.Text = "c"
        '
        'txtDepositBeforeBalance
        '
        Me.txtDepositBeforeBalance.BackColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(235, Byte), Integer), CType(CType(247, Byte), Integer))
        Me.txtDepositBeforeBalance.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txtDepositBeforeBalance.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtDepositBeforeBalance.Enabled = False
        Me.txtDepositBeforeBalance.Location = New System.Drawing.Point(559, 4)
        Me.txtDepositBeforeBalance.Name = "txtDepositBeforeBalance"
        Me.txtDepositBeforeBalance.ReadOnly = True
        Me.txtDepositBeforeBalance.Size = New System.Drawing.Size(104, 14)
        Me.txtDepositBeforeBalance.TabIndex = 10
        Me.txtDepositBeforeBalance.TabStop = False
        Me.txtDepositBeforeBalance.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.ToolTip1.SetToolTip(Me.txtDepositBeforeBalance, "Current Balance")
        '
        'txtCurrencyRate
        '
        Me.txtCurrencyRate.Location = New System.Drawing.Point(323, 21)
        Me.txtCurrencyRate.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.txtCurrencyRate.Name = "txtCurrencyRate"
        Me.txtCurrencyRate.Size = New System.Drawing.Size(71, 21)
        Me.txtCurrencyRate.TabIndex = 5
        Me.ToolTip1.SetToolTip(Me.txtCurrencyRate, "Enter Currency Rate")
        '
        'lblCurrencyRate
        '
        Me.lblCurrencyRate.AutoSize = True
        Me.lblCurrencyRate.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblCurrencyRate.Location = New System.Drawing.Point(320, 5)
        Me.lblCurrencyRate.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblCurrencyRate.Name = "lblCurrencyRate"
        Me.lblCurrencyRate.Size = New System.Drawing.Size(63, 13)
        Me.lblCurrencyRate.TabIndex = 4
        Me.lblCurrencyRate.Text = "Curr Rate"
        Me.ToolTip1.SetToolTip(Me.lblCurrencyRate, "Currency Rate")
        '
        'txtMemo
        '
        Appearance13.BackColor = System.Drawing.Color.Ivory
        Me.txtMemo.Appearance = Appearance13
        Me.txtMemo.BackColor = System.Drawing.Color.Ivory
        Me.txtMemo.ImageTransparentColor = System.Drawing.Color.Gainsboro
        Me.txtMemo.Location = New System.Drawing.Point(249, 60)
        Me.txtMemo.Name = "txtMemo"
        Me.txtMemo.Size = New System.Drawing.Size(241, 22)
        Me.txtMemo.TabIndex = 18
        Me.ToolTip1.SetToolTip(Me.txtMemo, "Enter reference")
        '
        'cmbCashAccount
        '
        Me.cmbCashAccount.BackColor = System.Drawing.SystemColors.Info
        Me.cmbCashAccount.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbCashAccount.FormattingEnabled = True
        Me.cmbCashAccount.Location = New System.Drawing.Point(495, 21)
        Me.cmbCashAccount.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.cmbCashAccount.Name = "cmbCashAccount"
        Me.cmbCashAccount.Size = New System.Drawing.Size(168, 21)
        Me.cmbCashAccount.TabIndex = 9
        Me.ToolTip1.SetToolTip(Me.cmbCashAccount, "Select Deposit Account")
        '
        'lblCompany
        '
        Me.lblCompany.AutoSize = True
        Me.lblCompany.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblCompany.Location = New System.Drawing.Point(2, 5)
        Me.lblCompany.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblCompany.Name = "lblCompany"
        Me.lblCompany.Size = New System.Drawing.Size(62, 13)
        Me.lblCompany.TabIndex = 0
        Me.lblCompany.Text = "Company"
        Me.ToolTip1.SetToolTip(Me.lblCompany, "Company")
        '
        'cmbVoucherType
        '
        Me.cmbVoucherType.BackColor = System.Drawing.SystemColors.Info
        Me.cmbVoucherType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbVoucherType.FormattingEnabled = True
        Me.cmbVoucherType.Location = New System.Drawing.Point(403, 21)
        Me.cmbVoucherType.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.cmbVoucherType.Name = "cmbVoucherType"
        Me.cmbVoucherType.Size = New System.Drawing.Size(87, 21)
        Me.cmbVoucherType.TabIndex = 7
        Me.ToolTip1.SetToolTip(Me.cmbVoucherType, "Select Pay Method")
        '
        'lblDocDate
        '
        Me.lblDocDate.AutoSize = True
        Me.lblDocDate.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblDocDate.Location = New System.Drawing.Point(117, 45)
        Me.lblDocDate.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblDocDate.Name = "lblDocDate"
        Me.lblDocDate.Size = New System.Drawing.Size(65, 13)
        Me.lblDocDate.TabIndex = 15
        Me.lblDocDate.Text = "Doc Date:"
        Me.ToolTip1.SetToolTip(Me.lblDocDate, "Document Date")
        '
        'dtVoucherDate
        '
        Me.dtVoucherDate.CustomFormat = "dd/MMM/yyyy"
        Me.dtVoucherDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.dtVoucherDate.Location = New System.Drawing.Point(120, 61)
        Me.dtVoucherDate.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.dtVoucherDate.Name = "dtVoucherDate"
        Me.dtVoucherDate.Size = New System.Drawing.Size(122, 21)
        Me.dtVoucherDate.TabIndex = 16
        Me.ToolTip1.SetToolTip(Me.dtVoucherDate, "Voucher Date")
        '
        'chkPost
        '
        Me.chkPost.AutoSize = True
        Me.chkPost.Checked = True
        Me.chkPost.CheckState = System.Windows.Forms.CheckState.Checked
        Me.chkPost.Location = New System.Drawing.Point(249, 86)
        Me.chkPost.Name = "chkPost"
        Me.chkPost.Size = New System.Drawing.Size(64, 17)
        Me.chkPost.TabIndex = 14
        Me.chkPost.Text = "Posted"
        Me.ToolTip1.SetToolTip(Me.chkPost, "Posted Voucher If Check On")
        Me.chkPost.UseVisualStyleBackColor = True
        '
        'chkChecked
        '
        Me.chkChecked.AutoSize = True
        Me.chkChecked.Location = New System.Drawing.Point(5, 85)
        Me.chkChecked.Name = "chkChecked"
        Me.chkChecked.Size = New System.Drawing.Size(76, 17)
        Me.chkChecked.TabIndex = 13
        Me.chkChecked.Text = "Checked"
        Me.ToolTip1.SetToolTip(Me.chkChecked, "Posted Voucher If Check On")
        Me.chkChecked.UseVisualStyleBackColor = True
        '
        'cmbCompany
        '
        Me.cmbCompany.BackColor = System.Drawing.SystemColors.Info
        Me.cmbCompany.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbCompany.FormattingEnabled = True
        Me.cmbCompany.Location = New System.Drawing.Point(4, 21)
        Me.cmbCompany.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.cmbCompany.Name = "cmbCompany"
        Me.cmbCompany.Size = New System.Drawing.Size(238, 21)
        Me.cmbCompany.TabIndex = 1
        Me.ToolTip1.SetToolTip(Me.cmbCompany, "Select Company")
        '
        'cmbCurrency
        '
        Me.cmbCurrency.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend
        Me.cmbCurrency.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
        Me.cmbCurrency.FormattingEnabled = True
        Me.cmbCurrency.Location = New System.Drawing.Point(249, 21)
        Me.cmbCurrency.Name = "cmbCurrency"
        Me.cmbCurrency.Size = New System.Drawing.Size(67, 21)
        Me.cmbCurrency.TabIndex = 3
        Me.ToolTip1.SetToolTip(Me.cmbCurrency, "Select Currency")
        '
        'lblCurrency
        '
        Me.lblCurrency.AutoSize = True
        Me.lblCurrency.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblCurrency.Location = New System.Drawing.Point(246, 5)
        Me.lblCurrency.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblCurrency.Name = "lblCurrency"
        Me.lblCurrency.Size = New System.Drawing.Size(60, 13)
        Me.lblCurrency.TabIndex = 2
        Me.lblCurrency.Text = "Currency"
        Me.ToolTip1.SetToolTip(Me.lblCurrency, "Currency")
        '
        'lblReference
        '
        Me.lblReference.AutoSize = True
        Me.lblReference.Location = New System.Drawing.Point(246, 45)
        Me.lblReference.Name = "lblReference"
        Me.lblReference.Size = New System.Drawing.Size(70, 13)
        Me.lblReference.TabIndex = 17
        Me.lblReference.Text = "Reference:"
        Me.ToolTip1.SetToolTip(Me.lblReference, "Refernece")
        '
        'lblPayMethod
        '
        Me.lblPayMethod.AutoSize = True
        Me.lblPayMethod.Location = New System.Drawing.Point(400, 5)
        Me.lblPayMethod.Name = "lblPayMethod"
        Me.lblPayMethod.Size = New System.Drawing.Size(73, 13)
        Me.lblPayMethod.TabIndex = 6
        Me.lblPayMethod.Text = "Pay Method"
        Me.ToolTip1.SetToolTip(Me.lblPayMethod, "Pay Method")
        '
        'txtVoucherNo
        '
        Me.txtVoucherNo.Location = New System.Drawing.Point(5, 61)
        Me.txtVoucherNo.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.txtVoucherNo.Name = "txtVoucherNo"
        Me.txtVoucherNo.ReadOnly = True
        Me.txtVoucherNo.Size = New System.Drawing.Size(107, 21)
        Me.txtVoucherNo.TabIndex = 12
        Me.txtVoucherNo.TabStop = False
        Me.ToolTip1.SetToolTip(Me.txtVoucherNo, "Voucher No:")
        '
        'lblRecieveIn
        '
        Me.lblRecieveIn.AutoSize = True
        Me.lblRecieveIn.Location = New System.Drawing.Point(494, 5)
        Me.lblRecieveIn.Name = "lblRecieveIn"
        Me.lblRecieveIn.Size = New System.Drawing.Size(66, 13)
        Me.lblRecieveIn.TabIndex = 8
        Me.lblRecieveIn.Text = "Pay From:"
        Me.ToolTip1.SetToolTip(Me.lblRecieveIn, "Pay From:")
        '
        'lblVoucherNo
        '
        Me.lblVoucherNo.AutoSize = True
        Me.lblVoucherNo.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblVoucherNo.Location = New System.Drawing.Point(2, 45)
        Me.lblVoucherNo.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblVoucherNo.Name = "lblVoucherNo"
        Me.lblVoucherNo.Size = New System.Drawing.Size(102, 13)
        Me.lblVoucherNo.TabIndex = 11
        Me.lblVoucherNo.Text = "Voucher Number"
        Me.ToolTip1.SetToolTip(Me.lblVoucherNo, "Voucher No")
        '
        'Panel2
        '
        Me.Panel2.Controls.Add(Me.chkAllAccounts)
        Me.Panel2.Controls.Add(Me.cmbInvoice)
        Me.Panel2.Controls.Add(Me.lblInvoice)
        Me.Panel2.Controls.Add(Me.lblNetAmountNumberConvertor)
        Me.Panel2.Controls.Add(Me.lblAmountNumberConvertor)
        Me.Panel2.Controls.Add(Me.lblPayment)
        Me.Panel2.Controls.Add(Me.txtCustomerBalance)
        Me.Panel2.Controls.Add(Me.txtTax)
        Me.Panel2.Controls.Add(Me.Label30)
        Me.Panel2.Controls.Add(Me.txtTaxAmount)
        Me.Panel2.Controls.Add(Me.Label31)
        Me.Panel2.Controls.Add(Me.txtAmount)
        Me.Panel2.Controls.Add(Me.txtNetAmount)
        Me.Panel2.Controls.Add(Me.Label3)
        Me.Panel2.Controls.Add(Me.txtWithHoldingTaxAmount)
        Me.Panel2.Controls.Add(Me.lblWH)
        Me.Panel2.Controls.Add(Me.txtWithHolding)
        Me.Panel2.Controls.Add(Me.lblNetAmount)
        Me.Panel2.Controls.Add(Me.Label1)
        Me.Panel2.Controls.Add(Me.txtSalesTaxAmount)
        Me.Panel2.Controls.Add(Me.cmbAccounts)
        Me.Panel2.Controls.Add(Me.txtDiscount)
        Me.Panel2.Controls.Add(Me.txtSalesTax)
        Me.Panel2.Controls.Add(Me.Label29)
        Me.Panel2.Controls.Add(Me.lblWHTaxAmount)
        Me.Panel2.Controls.Add(Me.lblSalesTax)
        Me.Panel2.Controls.Add(Me.lblSalesTaxAmount)
        Me.Panel2.Controls.Add(Me.lblGrossAmount)
        Me.Panel2.Controls.Add(Me.txtGrossAmount)
        Me.Panel2.Controls.Add(Me.cmbSalesTax)
        Me.Panel2.Controls.Add(Me.lblIncomeTaxAccount)
        Me.Panel2.Controls.Add(Me.lblSales)
        Me.Panel2.Controls.Add(Me.cmbIncomeTaxAccount)
        Me.Panel2.Controls.Add(Me.FlowLayoutPanel1)
        Me.Panel2.Location = New System.Drawing.Point(3, 132)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(944, 294)
        Me.Panel2.TabIndex = 2
        '
        'chkAllAccounts
        '
        Me.chkAllAccounts.AutoSize = True
        Me.chkAllAccounts.Location = New System.Drawing.Point(148, 35)
        Me.chkAllAccounts.Name = "chkAllAccounts"
        Me.chkAllAccounts.Size = New System.Drawing.Size(95, 17)
        Me.chkAllAccounts.TabIndex = 40
        Me.chkAllAccounts.TabStop = False
        Me.chkAllAccounts.Text = "All Accounts"
        Me.ToolTip1.SetToolTip(Me.chkAllAccounts, "All Accounts")
        Me.chkAllAccounts.UseVisualStyleBackColor = True
        '
        'cmbInvoice
        '
        Appearance7.BackColor = System.Drawing.SystemColors.Info
        Me.cmbInvoice.Appearance = Appearance7
        Me.cmbInvoice.AutoCompleteMode = Infragistics.Win.AutoCompleteMode.Suggest
        Me.cmbInvoice.AutoSuggestFilterMode = Infragistics.Win.AutoSuggestFilterMode.Contains
        Me.cmbInvoice.CheckedListSettings.CheckStateMember = ""
        Appearance8.BackColor = System.Drawing.Color.White
        Me.cmbInvoice.DisplayLayout.Appearance = Appearance8
        UltraGridColumn7.Header.VisiblePosition = 0
        UltraGridColumn7.Hidden = True
        UltraGridColumn8.Header.VisiblePosition = 1
        UltraGridColumn8.Width = 141
        UltraGridColumn9.Header.VisiblePosition = 2
        UltraGridColumn10.Header.VisiblePosition = 3
        UltraGridColumn11.Header.VisiblePosition = 4
        UltraGridColumn12.Header.VisiblePosition = 5
        UltraGridColumn12.Hidden = True
        UltraGridBand2.Columns.AddRange(New Object() {UltraGridColumn7, UltraGridColumn8, UltraGridColumn9, UltraGridColumn10, UltraGridColumn11, UltraGridColumn12})
        Me.cmbInvoice.DisplayLayout.BandsSerializer.Add(UltraGridBand2)
        Me.cmbInvoice.DisplayLayout.Override.AllowAddNew = Infragistics.Win.UltraWinGrid.AllowAddNew.No
        Me.cmbInvoice.DisplayLayout.Override.AllowDelete = Infragistics.Win.DefaultableBoolean.[False]
        Me.cmbInvoice.DisplayLayout.Override.AllowUpdate = Infragistics.Win.DefaultableBoolean.[False]
        Me.cmbInvoice.DisplayLayout.Override.BorderStyleCell = Infragistics.Win.UIElementBorderStyle.None
        Appearance9.BackColor = System.Drawing.Color.Transparent
        Me.cmbInvoice.DisplayLayout.Override.CardAreaAppearance = Appearance9
        Me.cmbInvoice.DisplayLayout.Override.CellClickAction = Infragistics.Win.UltraWinGrid.CellClickAction.RowSelect
        Me.cmbInvoice.DisplayLayout.Override.CellPadding = 3
        Me.cmbInvoice.DisplayLayout.Override.ColumnAutoSizeMode = Infragistics.Win.UltraWinGrid.ColumnAutoSizeMode.AllRowsInBand
        Appearance10.TextHAlignAsString = "Left"
        Me.cmbInvoice.DisplayLayout.Override.HeaderAppearance = Appearance10
        Me.cmbInvoice.DisplayLayout.Override.HeaderClickAction = Infragistics.Win.UltraWinGrid.HeaderClickAction.SortMulti
        Appearance11.BorderColor = System.Drawing.Color.LightGray
        Appearance11.TextVAlignAsString = "Middle"
        Me.cmbInvoice.DisplayLayout.Override.RowAppearance = Appearance11
        Appearance12.BackColor = System.Drawing.Color.LightSteelBlue
        Appearance12.BorderColor = System.Drawing.Color.Black
        Appearance12.ForeColor = System.Drawing.Color.Black
        Me.cmbInvoice.DisplayLayout.Override.SelectedRowAppearance = Appearance12
        Me.cmbInvoice.DisplayLayout.Override.SelectTypeCell = Infragistics.Win.UltraWinGrid.SelectType.None
        Me.cmbInvoice.DisplayLayout.Override.SelectTypeCol = Infragistics.Win.UltraWinGrid.SelectType.None
        Me.cmbInvoice.DisplayLayout.Override.SelectTypeRow = Infragistics.Win.UltraWinGrid.SelectType.[Single]
        Me.cmbInvoice.DisplayLayout.RowConnectorStyle = Infragistics.Win.UltraWinGrid.RowConnectorStyle.None
        Me.cmbInvoice.DisplayLayout.ScrollBounds = Infragistics.Win.UltraWinGrid.ScrollBounds.ScrollToFill
        Me.cmbInvoice.DisplayLayout.ScrollStyle = Infragistics.Win.UltraWinGrid.ScrollStyle.Immediate
        Me.cmbInvoice.DisplayLayout.TabNavigation = Infragistics.Win.UltraWinGrid.TabNavigation.NextControl
        Me.cmbInvoice.DisplayLayout.ViewStyle = Infragistics.Win.UltraWinGrid.ViewStyle.SingleBand
        Me.cmbInvoice.LimitToList = True
        Me.cmbInvoice.Location = New System.Drawing.Point(101, 165)
        Me.cmbInvoice.Name = "cmbInvoice"
        Me.cmbInvoice.Size = New System.Drawing.Size(141, 23)
        Me.cmbInvoice.TabIndex = 32
        '
        'lblInvoice
        '
        Me.lblInvoice.AutoSize = True
        Me.lblInvoice.Location = New System.Drawing.Point(3, 171)
        Me.lblInvoice.Name = "lblInvoice"
        Me.lblInvoice.Size = New System.Drawing.Size(95, 13)
        Me.lblInvoice.TabIndex = 33
        Me.lblInvoice.Text = "Sales Invoices:"
        '
        'lblNetAmountNumberConvertor
        '
        Me.lblNetAmountNumberConvertor.AutoSize = True
        Me.lblNetAmountNumberConvertor.Location = New System.Drawing.Point(405, 188)
        Me.lblNetAmountNumberConvertor.Name = "lblNetAmountNumberConvertor"
        Me.lblNetAmountNumberConvertor.Size = New System.Drawing.Size(12, 13)
        Me.lblNetAmountNumberConvertor.TabIndex = 31
        Me.lblNetAmountNumberConvertor.Text = "-"
        '
        'lblAmountNumberConvertor
        '
        Me.lblAmountNumberConvertor.AutoSize = True
        Me.lblAmountNumberConvertor.Location = New System.Drawing.Point(251, 80)
        Me.lblAmountNumberConvertor.Name = "lblAmountNumberConvertor"
        Me.lblAmountNumberConvertor.Size = New System.Drawing.Size(12, 13)
        Me.lblAmountNumberConvertor.TabIndex = 30
        Me.lblAmountNumberConvertor.Text = "-"
        '
        'lblPayment
        '
        Me.lblPayment.AutoSize = True
        Me.lblPayment.Font = New System.Drawing.Font("Verdana", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblPayment.ForeColor = System.Drawing.Color.Navy
        Me.lblPayment.Location = New System.Drawing.Point(3, 13)
        Me.lblPayment.Name = "lblPayment"
        Me.lblPayment.Size = New System.Drawing.Size(667, 18)
        Me.lblPayment.TabIndex = 0
        Me.lblPayment.Text = "Payment Details: ______________________________________________"
        Me.ToolTip1.SetToolTip(Me.lblPayment, "Payment Detail")
        '
        'txtCustomerBalance
        '
        Me.txtCustomerBalance.BackColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(235, Byte), Integer), CType(CType(247, Byte), Integer))
        Me.txtCustomerBalance.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txtCustomerBalance.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtCustomerBalance.Enabled = False
        Me.txtCustomerBalance.Location = New System.Drawing.Point(139, 38)
        Me.txtCustomerBalance.Name = "txtCustomerBalance"
        Me.txtCustomerBalance.ReadOnly = True
        Me.txtCustomerBalance.Size = New System.Drawing.Size(104, 14)
        Me.txtCustomerBalance.TabIndex = 3
        Me.txtCustomerBalance.TabStop = False
        Me.txtCustomerBalance.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.ToolTip1.SetToolTip(Me.txtCustomerBalance, "Current Cash Balance")
        '
        'txtTax
        '
        Me.txtTax.Location = New System.Drawing.Point(405, 94)
        Me.txtTax.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.txtTax.Name = "txtTax"
        Me.txtTax.Size = New System.Drawing.Size(87, 21)
        Me.txtTax.TabIndex = 13
        Me.txtTax.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.ToolTip1.SetToolTip(Me.txtTax, "Enter Tax Percentage")
        '
        'Label30
        '
        Me.Label30.AutoSize = True
        Me.Label30.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label30.Location = New System.Drawing.Point(402, 81)
        Me.Label30.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label30.Name = "Label30"
        Me.Label30.Size = New System.Drawing.Size(44, 13)
        Me.Label30.TabIndex = 12
        Me.Label30.Text = "Tax%:"
        Me.ToolTip1.SetToolTip(Me.Label30, "Tax%")
        '
        'txtTaxAmount
        '
        Me.txtTaxAmount.Location = New System.Drawing.Point(499, 94)
        Me.txtTaxAmount.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.txtTaxAmount.Name = "txtTaxAmount"
        Me.txtTaxAmount.Size = New System.Drawing.Size(167, 21)
        Me.txtTaxAmount.TabIndex = 15
        Me.txtTaxAmount.TabStop = False
        Me.txtTaxAmount.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.ToolTip1.SetToolTip(Me.txtTaxAmount, "Tax Amount")
        '
        'Label31
        '
        Me.Label31.AutoSize = True
        Me.Label31.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label31.Location = New System.Drawing.Point(496, 81)
        Me.Label31.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label31.Name = "Label31"
        Me.Label31.Size = New System.Drawing.Size(80, 13)
        Me.Label31.TabIndex = 14
        Me.Label31.Text = "Tax Amount:"
        Me.ToolTip1.SetToolTip(Me.Label31, "Tax Amount")
        '
        'txtAmount
        '
        Me.txtAmount.Location = New System.Drawing.Point(249, 55)
        Me.txtAmount.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.txtAmount.Name = "txtAmount"
        Me.txtAmount.Size = New System.Drawing.Size(149, 21)
        Me.txtAmount.TabIndex = 5
        Me.txtAmount.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.ToolTip1.SetToolTip(Me.txtAmount, "Enter Amount")
        '
        'txtNetAmount
        '
        Me.txtNetAmount.BackColor = System.Drawing.SystemColors.Info
        Me.txtNetAmount.Font = New System.Drawing.Font("Verdana", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtNetAmount.Location = New System.Drawing.Point(405, 161)
        Me.txtNetAmount.Name = "txtNetAmount"
        Me.txtNetAmount.ReadOnly = True
        Me.txtNetAmount.Size = New System.Drawing.Size(261, 24)
        Me.txtNetAmount.TabIndex = 27
        Me.txtNetAmount.TabStop = False
        Me.txtNetAmount.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.ToolTip1.SetToolTip(Me.txtNetAmount, "Net Amount")
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(246, 39)
        Me.Label3.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(56, 13)
        Me.Label3.TabIndex = 4
        Me.Label3.Text = "Amount:"
        Me.ToolTip1.SetToolTip(Me.Label3, "Amount")
        '
        'txtWithHoldingTaxAmount
        '
        Me.txtWithHoldingTaxAmount.BackColor = System.Drawing.SystemColors.Control
        Me.txtWithHoldingTaxAmount.Location = New System.Drawing.Point(498, 134)
        Me.txtWithHoldingTaxAmount.Name = "txtWithHoldingTaxAmount"
        Me.txtWithHoldingTaxAmount.Size = New System.Drawing.Size(167, 21)
        Me.txtWithHoldingTaxAmount.TabIndex = 25
        Me.txtWithHoldingTaxAmount.TabStop = False
        Me.txtWithHoldingTaxAmount.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.ToolTip1.SetToolTip(Me.txtWithHoldingTaxAmount, "With Holding Tax amount")
        '
        'lblWH
        '
        Me.lblWH.AutoSize = True
        Me.lblWH.Location = New System.Drawing.Point(402, 118)
        Me.lblWH.Name = "lblWH"
        Me.lblWH.Size = New System.Drawing.Size(43, 13)
        Me.lblWH.TabIndex = 22
        Me.lblWH.Text = "WH%:"
        Me.ToolTip1.SetToolTip(Me.lblWH, "With Holding Percentage")
        '
        'txtWithHolding
        '
        Me.txtWithHolding.Location = New System.Drawing.Point(405, 134)
        Me.txtWithHolding.Name = "txtWithHolding"
        Me.txtWithHolding.Size = New System.Drawing.Size(87, 21)
        Me.txtWithHolding.TabIndex = 23
        Me.txtWithHolding.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.ToolTip1.SetToolTip(Me.txtWithHolding, "Enter With Holding Percentage")
        '
        'lblNetAmount
        '
        Me.lblNetAmount.AutoSize = True
        Me.lblNetAmount.Font = New System.Drawing.Font("Verdana", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblNetAmount.Location = New System.Drawing.Point(315, 165)
        Me.lblNetAmount.Name = "lblNetAmount"
        Me.lblNetAmount.Size = New System.Drawing.Size(84, 14)
        Me.lblNetAmount.TabIndex = 26
        Me.lblNetAmount.Text = "Net Amount"
        Me.ToolTip1.SetToolTip(Me.lblNetAmount, "Net Amount")
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(4, 39)
        Me.Label1.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(99, 13)
        Me.Label1.TabIndex = 1
        Me.Label1.Text = "Pay To Account:"
        Me.ToolTip1.SetToolTip(Me.Label1, "Pay To Vendor")
        '
        'txtSalesTaxAmount
        '
        Me.txtSalesTaxAmount.BackColor = System.Drawing.SystemColors.Control
        Me.txtSalesTaxAmount.Location = New System.Drawing.Point(311, 134)
        Me.txtSalesTaxAmount.Name = "txtSalesTaxAmount"
        Me.txtSalesTaxAmount.Size = New System.Drawing.Size(87, 21)
        Me.txtSalesTaxAmount.TabIndex = 21
        Me.txtSalesTaxAmount.TabStop = False
        Me.txtSalesTaxAmount.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.ToolTip1.SetToolTip(Me.txtSalesTaxAmount, "Sales Tax Amount for WH tax calculation")
        '
        'cmbAccounts
        '
        Appearance14.BackColor = System.Drawing.SystemColors.Info
        Me.cmbAccounts.Appearance = Appearance14
        Me.cmbAccounts.AutoCompleteMode = Infragistics.Win.AutoCompleteMode.Suggest
        Me.cmbAccounts.AutoSuggestFilterMode = Infragistics.Win.AutoSuggestFilterMode.Contains
        Me.cmbAccounts.CheckedListSettings.CheckStateMember = ""
        Appearance15.BackColor = System.Drawing.Color.White
        Me.cmbAccounts.DisplayLayout.Appearance = Appearance15
        UltraGridColumn13.Header.VisiblePosition = 0
        UltraGridColumn13.Hidden = True
        UltraGridColumn14.Header.VisiblePosition = 1
        UltraGridColumn14.Width = 141
        UltraGridColumn15.Header.VisiblePosition = 2
        UltraGridColumn16.Header.VisiblePosition = 3
        UltraGridColumn17.Header.VisiblePosition = 4
        UltraGridColumn18.Header.VisiblePosition = 5
        UltraGridColumn18.Hidden = True
        UltraGridBand3.Columns.AddRange(New Object() {UltraGridColumn13, UltraGridColumn14, UltraGridColumn15, UltraGridColumn16, UltraGridColumn17, UltraGridColumn18})
        Me.cmbAccounts.DisplayLayout.BandsSerializer.Add(UltraGridBand3)
        Me.cmbAccounts.DisplayLayout.Override.AllowAddNew = Infragistics.Win.UltraWinGrid.AllowAddNew.No
        Me.cmbAccounts.DisplayLayout.Override.AllowDelete = Infragistics.Win.DefaultableBoolean.[False]
        Me.cmbAccounts.DisplayLayout.Override.AllowUpdate = Infragistics.Win.DefaultableBoolean.[False]
        Me.cmbAccounts.DisplayLayout.Override.BorderStyleCell = Infragistics.Win.UIElementBorderStyle.None
        Appearance16.BackColor = System.Drawing.Color.Transparent
        Me.cmbAccounts.DisplayLayout.Override.CardAreaAppearance = Appearance16
        Me.cmbAccounts.DisplayLayout.Override.CellClickAction = Infragistics.Win.UltraWinGrid.CellClickAction.RowSelect
        Me.cmbAccounts.DisplayLayout.Override.CellPadding = 3
        Me.cmbAccounts.DisplayLayout.Override.ColumnAutoSizeMode = Infragistics.Win.UltraWinGrid.ColumnAutoSizeMode.AllRowsInBand
        Appearance17.TextHAlignAsString = "Left"
        Me.cmbAccounts.DisplayLayout.Override.HeaderAppearance = Appearance17
        Me.cmbAccounts.DisplayLayout.Override.HeaderClickAction = Infragistics.Win.UltraWinGrid.HeaderClickAction.SortMulti
        Appearance18.BorderColor = System.Drawing.Color.LightGray
        Appearance18.TextVAlignAsString = "Middle"
        Me.cmbAccounts.DisplayLayout.Override.RowAppearance = Appearance18
        Appearance19.BackColor = System.Drawing.Color.LightSteelBlue
        Appearance19.BorderColor = System.Drawing.Color.Black
        Appearance19.ForeColor = System.Drawing.Color.Black
        Me.cmbAccounts.DisplayLayout.Override.SelectedRowAppearance = Appearance19
        Me.cmbAccounts.DisplayLayout.Override.SelectTypeCell = Infragistics.Win.UltraWinGrid.SelectType.None
        Me.cmbAccounts.DisplayLayout.Override.SelectTypeCol = Infragistics.Win.UltraWinGrid.SelectType.None
        Me.cmbAccounts.DisplayLayout.Override.SelectTypeRow = Infragistics.Win.UltraWinGrid.SelectType.[Single]
        Me.cmbAccounts.DisplayLayout.RowConnectorStyle = Infragistics.Win.UltraWinGrid.RowConnectorStyle.None
        Me.cmbAccounts.DisplayLayout.ScrollBounds = Infragistics.Win.UltraWinGrid.ScrollBounds.ScrollToFill
        Me.cmbAccounts.DisplayLayout.ScrollStyle = Infragistics.Win.UltraWinGrid.ScrollStyle.Immediate
        Me.cmbAccounts.DisplayLayout.TabNavigation = Infragistics.Win.UltraWinGrid.TabNavigation.NextControl
        Me.cmbAccounts.DisplayLayout.ViewStyle = Infragistics.Win.UltraWinGrid.ViewStyle.SingleBand
        Me.cmbAccounts.LimitToList = True
        Me.cmbAccounts.Location = New System.Drawing.Point(6, 55)
        Me.cmbAccounts.Name = "cmbAccounts"
        Me.cmbAccounts.Size = New System.Drawing.Size(238, 23)
        Me.cmbAccounts.TabIndex = 2
        Me.ToolTip1.SetToolTip(Me.cmbAccounts, "Select account for payment")
        '
        'txtDiscount
        '
        Me.txtDiscount.Location = New System.Drawing.Point(405, 55)
        Me.txtDiscount.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.txtDiscount.Name = "txtDiscount"
        Me.txtDiscount.Size = New System.Drawing.Size(87, 21)
        Me.txtDiscount.TabIndex = 7
        Me.txtDiscount.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.ToolTip1.SetToolTip(Me.txtDiscount, "Enter Discount")
        '
        'txtSalesTax
        '
        Me.txtSalesTax.Location = New System.Drawing.Point(249, 134)
        Me.txtSalesTax.Name = "txtSalesTax"
        Me.txtSalesTax.Size = New System.Drawing.Size(56, 21)
        Me.txtSalesTax.TabIndex = 19
        Me.txtSalesTax.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.ToolTip1.SetToolTip(Me.txtSalesTax, "Enter Sales Tax Percentage")
        '
        'Label29
        '
        Me.Label29.AutoSize = True
        Me.Label29.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label29.Location = New System.Drawing.Point(402, 39)
        Me.Label29.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label29.Name = "Label29"
        Me.Label29.Size = New System.Drawing.Size(61, 13)
        Me.Label29.TabIndex = 6
        Me.Label29.Text = "Discount:"
        Me.ToolTip1.SetToolTip(Me.Label29, "Discount")
        '
        'lblWHTaxAmount
        '
        Me.lblWHTaxAmount.AutoSize = True
        Me.lblWHTaxAmount.Location = New System.Drawing.Point(496, 118)
        Me.lblWHTaxAmount.Name = "lblWHTaxAmount"
        Me.lblWHTaxAmount.Size = New System.Drawing.Size(103, 13)
        Me.lblWHTaxAmount.TabIndex = 24
        Me.lblWHTaxAmount.Text = "WH Tax Amount:"
        Me.ToolTip1.SetToolTip(Me.lblWHTaxAmount, "WH Tax amount")
        '
        'lblSalesTax
        '
        Me.lblSalesTax.AutoSize = True
        Me.lblSalesTax.Location = New System.Drawing.Point(246, 118)
        Me.lblSalesTax.Name = "lblSalesTax"
        Me.lblSalesTax.Size = New System.Drawing.Size(56, 13)
        Me.lblSalesTax.TabIndex = 18
        Me.lblSalesTax.Text = "S.Tax%:"
        Me.ToolTip1.SetToolTip(Me.lblSalesTax, "Sales Tax Percentage")
        '
        'lblSalesTaxAmount
        '
        Me.lblSalesTaxAmount.AutoSize = True
        Me.lblSalesTaxAmount.Location = New System.Drawing.Point(309, 118)
        Me.lblSalesTaxAmount.Name = "lblSalesTaxAmount"
        Me.lblSalesTaxAmount.Size = New System.Drawing.Size(92, 13)
        Me.lblSalesTaxAmount.TabIndex = 20
        Me.lblSalesTaxAmount.Text = "S.Tax Amount:"
        Me.ToolTip1.SetToolTip(Me.lblSalesTaxAmount, "Sales Tax Amount")
        '
        'lblGrossAmount
        '
        Me.lblGrossAmount.AutoSize = True
        Me.lblGrossAmount.Location = New System.Drawing.Point(496, 39)
        Me.lblGrossAmount.Name = "lblGrossAmount"
        Me.lblGrossAmount.Size = New System.Drawing.Size(93, 13)
        Me.lblGrossAmount.TabIndex = 8
        Me.lblGrossAmount.Text = "Gross Amount:"
        Me.ToolTip1.SetToolTip(Me.lblGrossAmount, "Gross Amount")
        '
        'txtGrossAmount
        '
        Me.txtGrossAmount.Location = New System.Drawing.Point(499, 55)
        Me.txtGrossAmount.Name = "txtGrossAmount"
        Me.txtGrossAmount.ReadOnly = True
        Me.txtGrossAmount.Size = New System.Drawing.Size(166, 21)
        Me.txtGrossAmount.TabIndex = 9
        Me.txtGrossAmount.TabStop = False
        Me.txtGrossAmount.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.ToolTip1.SetToolTip(Me.txtGrossAmount, "Gross Amount")
        '
        'cmbSalesTax
        '
        Me.cmbSalesTax.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbSalesTax.FormattingEnabled = True
        Me.cmbSalesTax.Location = New System.Drawing.Point(6, 134)
        Me.cmbSalesTax.Name = "cmbSalesTax"
        Me.cmbSalesTax.Size = New System.Drawing.Size(238, 21)
        Me.cmbSalesTax.TabIndex = 17
        Me.ToolTip1.SetToolTip(Me.cmbSalesTax, "select any sales tax ")
        '
        'lblIncomeTaxAccount
        '
        Me.lblIncomeTaxAccount.AutoSize = True
        Me.lblIncomeTaxAccount.Location = New System.Drawing.Point(3, 81)
        Me.lblIncomeTaxAccount.Name = "lblIncomeTaxAccount"
        Me.lblIncomeTaxAccount.Size = New System.Drawing.Size(128, 13)
        Me.lblIncomeTaxAccount.TabIndex = 10
        Me.lblIncomeTaxAccount.Text = "Income Tax Account:"
        Me.ToolTip1.SetToolTip(Me.lblIncomeTaxAccount, "Income Tax Account:")
        '
        'lblSales
        '
        Me.lblSales.AutoSize = True
        Me.lblSales.Location = New System.Drawing.Point(4, 118)
        Me.lblSales.Name = "lblSales"
        Me.lblSales.Size = New System.Drawing.Size(116, 13)
        Me.lblSales.TabIndex = 16
        Me.lblSales.Text = "Sales Tax Account:"
        Me.ToolTip1.SetToolTip(Me.lblSales, "Select Sales Tax Account")
        '
        'cmbIncomeTaxAccount
        '
        Me.cmbIncomeTaxAccount.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbIncomeTaxAccount.FormattingEnabled = True
        Me.cmbIncomeTaxAccount.Location = New System.Drawing.Point(6, 97)
        Me.cmbIncomeTaxAccount.Name = "cmbIncomeTaxAccount"
        Me.cmbIncomeTaxAccount.Size = New System.Drawing.Size(238, 21)
        Me.cmbIncomeTaxAccount.TabIndex = 11
        Me.ToolTip1.SetToolTip(Me.cmbIncomeTaxAccount, "Select Income Tax Account")
        '
        'FlowLayoutPanel1
        '
        Me.FlowLayoutPanel1.Controls.Add(Me.pnlBank)
        Me.FlowLayoutPanel1.Controls.Add(Me.pnlCost)
        Me.FlowLayoutPanel1.Location = New System.Drawing.Point(0, 202)
        Me.FlowLayoutPanel1.Name = "FlowLayoutPanel1"
        Me.FlowLayoutPanel1.Size = New System.Drawing.Size(812, 99)
        Me.FlowLayoutPanel1.TabIndex = 29
        '
        'pnlBank
        '
        Me.pnlBank.Controls.Add(Me.Label36)
        Me.pnlBank.Controls.Add(Me.cmbChequeBook)
        Me.pnlBank.Controls.Add(Me.Label4)
        Me.pnlBank.Controls.Add(Me.cmbBank)
        Me.pnlBank.Controls.Add(Me.txtChequeNo)
        Me.pnlBank.Controls.Add(Me.dtChequeDate)
        Me.pnlBank.Controls.Add(Me.Label5)
        Me.pnlBank.Controls.Add(Me.Label17)
        Me.pnlBank.Location = New System.Drawing.Point(3, 0)
        Me.pnlBank.Margin = New System.Windows.Forms.Padding(3, 0, 3, 3)
        Me.pnlBank.Name = "pnlBank"
        Me.pnlBank.Size = New System.Drawing.Size(667, 40)
        Me.pnlBank.TabIndex = 0
        '
        'Label36
        '
        Me.Label36.AutoSize = True
        Me.Label36.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label36.Location = New System.Drawing.Point(1, 0)
        Me.Label36.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label36.Name = "Label36"
        Me.Label36.Size = New System.Drawing.Size(89, 13)
        Me.Label36.TabIndex = 6
        Me.Label36.Text = "Cheque Book:"
        '
        'cmbChequeBook
        '
        Me.cmbChequeBook.BackColor = System.Drawing.SystemColors.Info
        Me.cmbChequeBook.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbChequeBook.FormattingEnabled = True
        Me.cmbChequeBook.Location = New System.Drawing.Point(3, 16)
        Me.cmbChequeBook.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.cmbChequeBook.Name = "cmbChequeBook"
        Me.cmbChequeBook.Size = New System.Drawing.Size(127, 21)
        Me.cmbChequeBook.TabIndex = 1
        Me.ToolTip1.SetToolTip(Me.cmbChequeBook, "Select Cheque Book")
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(374, 0)
        Me.Label4.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(47, 13)
        Me.Label4.TabIndex = 4
        Me.Label4.Text = "Payee:"
        Me.ToolTip1.SetToolTip(Me.Label4, "Bank Description")
        '
        'cmbBank
        '
        Me.cmbBank.FormattingEnabled = True
        Me.cmbBank.Location = New System.Drawing.Point(377, 16)
        Me.cmbBank.Name = "cmbBank"
        Me.cmbBank.Size = New System.Drawing.Size(286, 21)
        Me.cmbBank.TabIndex = 5
        Me.ToolTip1.SetToolTip(Me.cmbBank, "Bank Description")
        '
        'txtChequeNo
        '
        Me.txtChequeNo.Location = New System.Drawing.Point(134, 16)
        Me.txtChequeNo.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.txtChequeNo.Name = "txtChequeNo"
        Me.txtChequeNo.Size = New System.Drawing.Size(110, 21)
        Me.txtChequeNo.TabIndex = 2
        Me.ToolTip1.SetToolTip(Me.txtChequeNo, "Cheque No")
        '
        'dtChequeDate
        '
        Me.dtChequeDate.CustomFormat = "dd-MMM-yyyy"
        Me.dtChequeDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.dtChequeDate.Location = New System.Drawing.Point(249, 16)
        Me.dtChequeDate.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.dtChequeDate.Name = "dtChequeDate"
        Me.dtChequeDate.Size = New System.Drawing.Size(121, 21)
        Me.dtChequeDate.TabIndex = 3
        Me.ToolTip1.SetToolTip(Me.dtChequeDate, "Cheque Date")
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(131, 0)
        Me.Label5.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(100, 13)
        Me.Label5.TabIndex = 0
        Me.Label5.Text = "Cheque Number"
        Me.ToolTip1.SetToolTip(Me.Label5, "Cheque Number")
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label17.Location = New System.Drawing.Point(246, 0)
        Me.Label17.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(39, 13)
        Me.Label17.TabIndex = 2
        Me.Label17.Text = "Date:"
        Me.ToolTip1.SetToolTip(Me.Label17, "Cheque Date")
        '
        'pnlCost
        '
        Me.pnlCost.Controls.Add(Me.lblCostCenter)
        Me.pnlCost.Controls.Add(Me.btnCancel)
        Me.pnlCost.Controls.Add(Me.btnReplace)
        Me.pnlCost.Controls.Add(Me.btnAdd)
        Me.pnlCost.Controls.Add(Me.txtReference)
        Me.pnlCost.Controls.Add(Me.cmbCostCenter)
        Me.pnlCost.Controls.Add(Me.lblDescription)
        Me.pnlCost.Controls.Add(Me.lblSaleman)
        Me.pnlCost.Controls.Add(Me.cmbSaleman)
        Me.pnlCost.Location = New System.Drawing.Point(3, 43)
        Me.pnlCost.Margin = New System.Windows.Forms.Padding(3, 0, 3, 3)
        Me.pnlCost.Name = "pnlCost"
        Me.pnlCost.Size = New System.Drawing.Size(808, 43)
        Me.pnlCost.TabIndex = 1
        '
        'lblCostCenter
        '
        Me.lblCostCenter.AutoSize = True
        Me.lblCostCenter.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblCostCenter.Location = New System.Drawing.Point(1, 0)
        Me.lblCostCenter.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblCostCenter.Name = "lblCostCenter"
        Me.lblCostCenter.Size = New System.Drawing.Size(81, 13)
        Me.lblCostCenter.TabIndex = 0
        Me.lblCostCenter.Text = "Cost Center:"
        Me.ToolTip1.SetToolTip(Me.lblCostCenter, "cost center")
        '
        'btnCancel
        '
        Me.btnCancel.Location = New System.Drawing.Point(739, 17)
        Me.btnCancel.Name = "btnCancel"
        Me.btnCancel.Size = New System.Drawing.Size(64, 23)
        Me.btnCancel.TabIndex = 4
        Me.btnCancel.Text = "Cancel"
        Me.btnCancel.UseVisualStyleBackColor = True
        Me.btnCancel.Visible = False
        '
        'btnReplace
        '
        Me.btnReplace.Location = New System.Drawing.Point(656, 14)
        Me.btnReplace.Name = "btnReplace"
        Me.btnReplace.Size = New System.Drawing.Size(64, 23)
        Me.btnReplace.TabIndex = 4
        Me.btnReplace.Text = "Replace"
        Me.btnReplace.UseVisualStyleBackColor = True
        Me.btnReplace.Visible = False
        '
        'btnAdd
        '
        Me.btnAdd.Location = New System.Drawing.Point(608, 16)
        Me.btnAdd.Name = "btnAdd"
        Me.btnAdd.Size = New System.Drawing.Size(55, 23)
        Me.btnAdd.TabIndex = 4
        Me.btnAdd.Text = "+"
        Me.ToolTip1.SetToolTip(Me.btnAdd, "Add Account To Grid (Insert)")
        Me.btnAdd.UseVisualStyleBackColor = True
        '
        'txtReference
        '
        Me.txtReference.Location = New System.Drawing.Point(136, 17)
        Me.txtReference.Name = "txtReference"
        Me.txtReference.Size = New System.Drawing.Size(234, 22)
        Me.txtReference.TabIndex = 3
        Me.ToolTip1.SetToolTip(Me.txtReference, "Enter Description")
        '
        'cmbCostCenter
        '
        Me.cmbCostCenter.FormattingEnabled = True
        Me.cmbCostCenter.Location = New System.Drawing.Point(3, 16)
        Me.cmbCostCenter.Name = "cmbCostCenter"
        Me.cmbCostCenter.Size = New System.Drawing.Size(127, 21)
        Me.cmbCostCenter.TabIndex = 1
        Me.ToolTip1.SetToolTip(Me.cmbCostCenter, "Select Cost Center")
        '
        'lblDescription
        '
        Me.lblDescription.AutoSize = True
        Me.lblDescription.Location = New System.Drawing.Point(133, 1)
        Me.lblDescription.Name = "lblDescription"
        Me.lblDescription.Size = New System.Drawing.Size(76, 13)
        Me.lblDescription.TabIndex = 2
        Me.lblDescription.Text = "Description:"
        Me.ToolTip1.SetToolTip(Me.lblDescription, "Description")
        '
        'lblSaleman
        '
        Me.lblSaleman.AutoSize = True
        Me.lblSaleman.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblSaleman.Location = New System.Drawing.Point(374, 1)
        Me.lblSaleman.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblSaleman.Name = "lblSaleman"
        Me.lblSaleman.Size = New System.Drawing.Size(63, 13)
        Me.lblSaleman.TabIndex = 19
        Me.lblSaleman.Text = "Employee"
        Me.ToolTip1.SetToolTip(Me.lblSaleman, "Sales Man")
        '
        'cmbSaleman
        '
        Me.cmbSaleman.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend
        Me.cmbSaleman.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
        Me.cmbSaleman.FormattingEnabled = True
        Me.cmbSaleman.Location = New System.Drawing.Point(377, 17)
        Me.cmbSaleman.Name = "cmbSaleman"
        Me.cmbSaleman.Size = New System.Drawing.Size(225, 21)
        Me.cmbSaleman.TabIndex = 20
        Me.ToolTip1.SetToolTip(Me.cmbSaleman, "Select Sales Man")
        '
        'ToolStrip1
        '
        Me.ToolStrip1.AutoSize = False
        Me.ToolStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.BtnNew, Me.BtnEdit, Me.BtnSave, Me.BtnDelete, Me.BtnPrint, Me.toolStripSeparator1, Me.btnUpdateTimes, Me.btnReminder, Me.BtnRefresh, Me.ToolStripSeparator3, Me.btnApprovalHistory, Me.btnAttachment, Me.ToolStripSeparator8, Me.btnSMSTemplate, Me.ToolStripSeparator9, Me.HelpToolStripButton, Me.ToolStripSeparator2, Me.TaxConfiguration, Me.ToolStripSeparator14, Me.btnBackToOldReciept, Me.ToolStripSeparator11, Me.ToolStripButton1, Me.cmbLayout, Me.ToolStripSeparator12, Me.btnPurchaseInvoiceSearch})
        Me.ToolStrip1.Location = New System.Drawing.Point(0, 0)
        Me.ToolStrip1.Name = "ToolStrip1"
        Me.ToolStrip1.Size = New System.Drawing.Size(1282, 25)
        Me.ToolStrip1.TabIndex = 0
        Me.ToolStrip1.Text = "ToolStrip1"
        '
        'BtnNew
        '
        Me.BtnNew.Image = Global.SimpleAccounts.My.Resources.Resources.BtnNew_Image
        Me.BtnNew.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.BtnNew.Name = "BtnNew"
        Me.BtnNew.Size = New System.Drawing.Size(51, 22)
        Me.BtnNew.Text = "&New"
        Me.BtnNew.ToolTipText = "New record mode (escape)"
        '
        'BtnEdit
        '
        Me.BtnEdit.Image = Global.SimpleAccounts.My.Resources.Resources.BtnEdit_Image
        Me.BtnEdit.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.BtnEdit.Name = "BtnEdit"
        Me.BtnEdit.Size = New System.Drawing.Size(47, 22)
        Me.BtnEdit.Text = "&Edit"
        Me.BtnEdit.ToolTipText = "Edit record (Alt+E)"
        '
        'BtnSave
        '
        Me.BtnSave.Image = Global.SimpleAccounts.My.Resources.Resources.BtnSave_Image
        Me.BtnSave.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.BtnSave.Name = "BtnSave"
        Me.BtnSave.Size = New System.Drawing.Size(51, 22)
        Me.BtnSave.Text = "&Save"
        Me.BtnSave.ToolTipText = "Save (F4)"
        '
        'BtnDelete
        '
        Me.BtnDelete.Image = Global.SimpleAccounts.My.Resources.Resources.BtnDelete_Image
        Me.BtnDelete.Name = "BtnDelete"
        Me.BtnDelete.RightToLeftAutoMirrorImage = True
        Me.BtnDelete.Size = New System.Drawing.Size(60, 22)
        Me.BtnDelete.Text = "&Delete"
        Me.BtnDelete.ToolTipText = "Delete (Alt+D)"
        '
        'BtnPrint
        '
        Me.BtnPrint.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.PrintReceiptToolStripMenuItem, Me.PrintAttachmentVoucherToolStripMenuItem, Me.PrintUpdatedVoucherToolStripMenuItem})
        Me.BtnPrint.Image = Global.SimpleAccounts.My.Resources.Resources.print
        Me.BtnPrint.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.BtnPrint.Name = "BtnPrint"
        Me.BtnPrint.Size = New System.Drawing.Size(64, 22)
        Me.BtnPrint.Text = "&Print"
        Me.BtnPrint.ToolTipText = "Print (Ctrl+P)"
        '
        'PrintReceiptToolStripMenuItem
        '
        Me.PrintReceiptToolStripMenuItem.Name = "PrintReceiptToolStripMenuItem"
        Me.PrintReceiptToolStripMenuItem.Size = New System.Drawing.Size(211, 22)
        Me.PrintReceiptToolStripMenuItem.Text = "Print Payment"
        '
        'PrintAttachmentVoucherToolStripMenuItem
        '
        Me.PrintAttachmentVoucherToolStripMenuItem.Name = "PrintAttachmentVoucherToolStripMenuItem"
        Me.PrintAttachmentVoucherToolStripMenuItem.Size = New System.Drawing.Size(211, 22)
        Me.PrintAttachmentVoucherToolStripMenuItem.Text = "Print Attachment Voucher"
        '
        'PrintUpdatedVoucherToolStripMenuItem
        '
        Me.PrintUpdatedVoucherToolStripMenuItem.Name = "PrintUpdatedVoucherToolStripMenuItem"
        Me.PrintUpdatedVoucherToolStripMenuItem.Size = New System.Drawing.Size(211, 22)
        Me.PrintUpdatedVoucherToolStripMenuItem.Text = "Print Updated Voucher"
        '
        'toolStripSeparator1
        '
        Me.toolStripSeparator1.Name = "toolStripSeparator1"
        Me.toolStripSeparator1.Size = New System.Drawing.Size(6, 25)
        '
        'btnUpdateTimes
        '
        Me.btnUpdateTimes.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.btnUpdateTimes.Name = "btnUpdateTimes"
        Me.btnUpdateTimes.Size = New System.Drawing.Size(125, 22)
        Me.btnUpdateTimes.Text = "No of update times"
        Me.btnUpdateTimes.ToolTipText = "Record update history"
        '
        'btnReminder
        '
        Me.btnReminder.Image = Global.SimpleAccounts.My.Resources.Resources.bell_icon
        Me.btnReminder.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.btnReminder.Name = "btnReminder"
        Me.btnReminder.Size = New System.Drawing.Size(78, 22)
        Me.btnReminder.Text = "Reminder"
        Me.btnReminder.ToolTipText = "Add a reminder (Ctrl+R)"
        '
        'BtnRefresh
        '
        Me.BtnRefresh.Image = Global.SimpleAccounts.My.Resources.Resources.Refresh
        Me.BtnRefresh.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.BtnRefresh.Name = "BtnRefresh"
        Me.BtnRefresh.Size = New System.Drawing.Size(66, 22)
        Me.BtnRefresh.Text = "Refresh"
        Me.BtnRefresh.ToolTipText = "Refresh data (F5)"
        '
        'ToolStripSeparator3
        '
        Me.ToolStripSeparator3.Name = "ToolStripSeparator3"
        Me.ToolStripSeparator3.Size = New System.Drawing.Size(6, 25)
        '
        'btnApprovalHistory
        '
        Me.btnApprovalHistory.Image = Global.SimpleAccounts.My.Resources.Resources.Copy
        Me.btnApprovalHistory.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.btnApprovalHistory.Name = "btnApprovalHistory"
        Me.btnApprovalHistory.Size = New System.Drawing.Size(116, 22)
        Me.btnApprovalHistory.Text = "Approval History"
        '
        'btnAttachment
        '
        Me.btnAttachment.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.btnPreviewAttachment})
        Me.btnAttachment.Image = Global.SimpleAccounts.My.Resources.Resources._1483443165_attachment_add
        Me.btnAttachment.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.btnAttachment.Name = "btnAttachment"
        Me.btnAttachment.Size = New System.Drawing.Size(102, 22)
        Me.btnAttachment.Text = "Attachment"
        Me.btnAttachment.ToolTipText = "Attach document (F6)"
        '
        'btnPreviewAttachment
        '
        Me.btnPreviewAttachment.Name = "btnPreviewAttachment"
        Me.btnPreviewAttachment.Size = New System.Drawing.Size(181, 22)
        Me.btnPreviewAttachment.Text = "Preview Attachment"
        '
        'ToolStripSeparator8
        '
        Me.ToolStripSeparator8.Name = "ToolStripSeparator8"
        Me.ToolStripSeparator8.Size = New System.Drawing.Size(6, 25)
        '
        'btnSMSTemplate
        '
        Me.btnSMSTemplate.Image = Global.SimpleAccounts.My.Resources.Resources.Attach
        Me.btnSMSTemplate.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.btnSMSTemplate.Name = "btnSMSTemplate"
        Me.btnSMSTemplate.Size = New System.Drawing.Size(140, 22)
        Me.btnSMSTemplate.Text = "SMS template Setting"
        Me.btnSMSTemplate.ToolTipText = "SMS template(F8)"
        '
        'ToolStripSeparator9
        '
        Me.ToolStripSeparator9.Name = "ToolStripSeparator9"
        Me.ToolStripSeparator9.Size = New System.Drawing.Size(6, 25)
        '
        'HelpToolStripButton
        '
        Me.HelpToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.HelpToolStripButton.Image = Global.SimpleAccounts.My.Resources.Resources.HelpToolStripButton_Image
        Me.HelpToolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.HelpToolStripButton.Name = "HelpToolStripButton"
        Me.HelpToolStripButton.Size = New System.Drawing.Size(23, 22)
        Me.HelpToolStripButton.Text = "He&lp"
        '
        'ToolStripSeparator2
        '
        Me.ToolStripSeparator2.Name = "ToolStripSeparator2"
        Me.ToolStripSeparator2.Size = New System.Drawing.Size(6, 25)
        '
        'TaxConfiguration
        '
        Me.TaxConfiguration.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text
        Me.TaxConfiguration.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.TaxConfiguration.Name = "TaxConfiguration"
        Me.TaxConfiguration.Size = New System.Drawing.Size(105, 22)
        Me.TaxConfiguration.Text = "Tax Configuration"
        '
        'ToolStripSeparator14
        '
        Me.ToolStripSeparator14.Name = "ToolStripSeparator14"
        Me.ToolStripSeparator14.Size = New System.Drawing.Size(6, 25)
        '
        'btnBackToOldReciept
        '
        Me.btnBackToOldReciept.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text
        Me.btnBackToOldReciept.Image = Global.SimpleAccounts.My.Resources.Resources.back
        Me.btnBackToOldReciept.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.btnBackToOldReciept.Name = "btnBackToOldReciept"
        Me.btnBackToOldReciept.Size = New System.Drawing.Size(123, 22)
        Me.btnBackToOldReciept.Text = "Back To Old Payment"
        Me.btnBackToOldReciept.ToolTipText = "Switch payment screen (Alt+O)"
        '
        'ToolStripSeparator11
        '
        Me.ToolStripSeparator11.Name = "ToolStripSeparator11"
        Me.ToolStripSeparator11.Size = New System.Drawing.Size(6, 25)
        '
        'ToolStripButton1
        '
        Me.ToolStripButton1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text
        Me.ToolStripButton1.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ToolStripButton1.Name = "ToolStripButton1"
        Me.ToolStripButton1.Size = New System.Drawing.Size(103, 19)
        Me.ToolStripButton1.Text = "Add New Vendor "
        '
        'cmbLayout
        '
        Me.cmbLayout.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbLayout.Items.AddRange(New Object() {"... Select Layout ...", "ABL", "HBL", "UBL", "Bank Al-Habib", "Bank Al-Falah", "Askari Bank", "Faysal Bank", "Meezan Bank", "Saadiq Standard Chartered", "MCB", "NBP", "Soneri Bank", "BIP", "Habib Metro", "NIB", "Kasab", "Silk Bank"})
        Me.cmbLayout.Name = "cmbLayout"
        Me.cmbLayout.Size = New System.Drawing.Size(121, 23)
        '
        'ToolStripSeparator12
        '
        Me.ToolStripSeparator12.Name = "ToolStripSeparator12"
        Me.ToolStripSeparator12.Size = New System.Drawing.Size(6, 25)
        '
        'btnPurchaseInvoiceSearch
        '
        Me.btnPurchaseInvoiceSearch.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text
        Me.btnPurchaseInvoiceSearch.Image = Global.SimpleAccounts.My.Resources.Resources.back
        Me.btnPurchaseInvoiceSearch.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.btnPurchaseInvoiceSearch.Name = "btnPurchaseInvoiceSearch"
        Me.btnPurchaseInvoiceSearch.Size = New System.Drawing.Size(100, 19)
        Me.btnPurchaseInvoiceSearch.Text = "Purchase Invoice"
        '
        'grdVoucher
        '
        Me.grdVoucher.Controls.Add(Me.CtrlGrdBar10)
        Me.grdVoucher.Controls.Add(Me.ToolStrip2)
        Me.grdVoucher.Controls.Add(Me.SplitContainer1)
        Me.grdVoucher.Location = New System.Drawing.Point(-10000, -10000)
        Me.grdVoucher.Name = "grdVoucher"
        Me.grdVoucher.Size = New System.Drawing.Size(1282, 668)
        '
        'CtrlGrdBar10
        '
        Me.CtrlGrdBar10.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.CtrlGrdBar10.BackColor = System.Drawing.Color.FromArgb(CType(CType(12, Byte), Integer), CType(CType(120, Byte), Integer), CType(CType(148, Byte), Integer))
        Me.CtrlGrdBar10.Email = Nothing
        Me.CtrlGrdBar10.FormName = Me
        Me.CtrlGrdBar10.Location = New System.Drawing.Point(1466, 3)
        Me.CtrlGrdBar10.MyGrid = Me.grdVouchers
        Me.CtrlGrdBar10.Name = "CtrlGrdBar10"
        Me.CtrlGrdBar10.Size = New System.Drawing.Size(38, 23)
        Me.CtrlGrdBar10.TabIndex = 17
        '
        'grdVouchers
        '
        Me.grdVouchers.AllowEdit = Janus.Windows.GridEX.InheritableBoolean.[False]
        Me.grdVouchers.Dock = System.Windows.Forms.DockStyle.Fill
        Me.grdVouchers.FilterMode = Janus.Windows.GridEX.FilterMode.Automatic
        Me.grdVouchers.FilterRowButtonStyle = Janus.Windows.GridEX.FilterRowButtonStyle.ConditionOperatorDropDown
        Me.grdVouchers.FilterRowUpdateMode = Janus.Windows.GridEX.FilterRowUpdateMode.WhenValueChanges
        Me.grdVouchers.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.grdVouchers.GroupByBoxVisible = False
        Me.grdVouchers.Location = New System.Drawing.Point(0, 0)
        Me.grdVouchers.Name = "grdVouchers"
        Me.grdVouchers.RecordNavigator = True
        Me.grdVouchers.ScrollBars = Janus.Windows.GridEX.ScrollBars.Both
        Me.grdVouchers.Size = New System.Drawing.Size(1282, 483)
        Me.grdVouchers.TabIndex = 2
        Me.ToolTip1.SetToolTip(Me.grdVouchers, "Saved Record Detail")
        Me.grdVouchers.TotalRow = Janus.Windows.GridEX.InheritableBoolean.[True]
        Me.grdVouchers.VisualStyle = Janus.Windows.GridEX.VisualStyle.Office2007
        '
        'ToolStrip2
        '
        Me.ToolStrip2.AutoSize = False
        Me.ToolStrip2.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.btnHisotryEdit, Me.ToolStripSeparator6, Me.btnSearchDelete, Me.ToolStripSeparator7, Me.btnHistoryPrint, Me.ToolStripSeparator10, Me.btnPrintUpdatedVoucher, Me.toolStripSeparator, Me.btnHistoryLoadAll, Me.btnHistorySearch, Me.ToolStripSeparator5, Me.btnReminder1, Me.Btn_SaveAttachment, Me.ToolStripSeparator4, Me.HelpToolStripButton1, Me.btnGetAllRecord})
        Me.ToolStrip2.Location = New System.Drawing.Point(0, 0)
        Me.ToolStrip2.Name = "ToolStrip2"
        Me.ToolStrip2.Size = New System.Drawing.Size(1282, 28)
        Me.ToolStrip2.TabIndex = 2
        Me.ToolStrip2.Text = "ToolStrip2"
        '
        'btnHisotryEdit
        '
        Me.btnHisotryEdit.Image = Global.SimpleAccounts.My.Resources.Resources.BtnEdit_Image
        Me.btnHisotryEdit.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.btnHisotryEdit.Name = "btnHisotryEdit"
        Me.btnHisotryEdit.Size = New System.Drawing.Size(47, 25)
        Me.btnHisotryEdit.Text = "&Edit"
        Me.btnHisotryEdit.ToolTipText = "(Alt+E)"
        '
        'ToolStripSeparator6
        '
        Me.ToolStripSeparator6.Name = "ToolStripSeparator6"
        Me.ToolStripSeparator6.Size = New System.Drawing.Size(6, 28)
        '
        'btnSearchDelete
        '
        Me.btnSearchDelete.Image = Global.SimpleAccounts.My.Resources.Resources.BtnDelete_Image
        Me.btnSearchDelete.Name = "btnSearchDelete"
        Me.btnSearchDelete.RightToLeftAutoMirrorImage = True
        Me.btnSearchDelete.Size = New System.Drawing.Size(60, 25)
        Me.btnSearchDelete.Text = "&Delete"
        Me.btnSearchDelete.ToolTipText = "(Alt+D)"
        '
        'ToolStripSeparator7
        '
        Me.ToolStripSeparator7.Name = "ToolStripSeparator7"
        Me.ToolStripSeparator7.Size = New System.Drawing.Size(6, 28)
        '
        'btnHistoryPrint
        '
        Me.btnHistoryPrint.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.PrintReceiptToolStripMenuItem1, Me.PrintSelectedVouchersToolStripMenuItem, Me.PrintAttachmentVoucherToolStripMenuItem1})
        Me.btnHistoryPrint.Image = Global.SimpleAccounts.My.Resources.Resources.print
        Me.btnHistoryPrint.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.btnHistoryPrint.Name = "btnHistoryPrint"
        Me.btnHistoryPrint.Size = New System.Drawing.Size(64, 25)
        Me.btnHistoryPrint.Text = "&Print"
        Me.btnHistoryPrint.ToolTipText = "(Ctrl+P)"
        '
        'PrintReceiptToolStripMenuItem1
        '
        Me.PrintReceiptToolStripMenuItem1.Name = "PrintReceiptToolStripMenuItem1"
        Me.PrintReceiptToolStripMenuItem1.Size = New System.Drawing.Size(211, 22)
        Me.PrintReceiptToolStripMenuItem1.Text = "Print Payment"
        '
        'PrintSelectedVouchersToolStripMenuItem
        '
        Me.PrintSelectedVouchersToolStripMenuItem.Name = "PrintSelectedVouchersToolStripMenuItem"
        Me.PrintSelectedVouchersToolStripMenuItem.Size = New System.Drawing.Size(211, 22)
        Me.PrintSelectedVouchersToolStripMenuItem.Text = "Print Selected Vouchers"
        '
        'PrintAttachmentVoucherToolStripMenuItem1
        '
        Me.PrintAttachmentVoucherToolStripMenuItem1.Name = "PrintAttachmentVoucherToolStripMenuItem1"
        Me.PrintAttachmentVoucherToolStripMenuItem1.Size = New System.Drawing.Size(211, 22)
        Me.PrintAttachmentVoucherToolStripMenuItem1.Text = "Print Attachment Voucher"
        '
        'ToolStripSeparator10
        '
        Me.ToolStripSeparator10.Name = "ToolStripSeparator10"
        Me.ToolStripSeparator10.Size = New System.Drawing.Size(6, 28)
        '
        'btnPrintUpdatedVoucher
        '
        Me.btnPrintUpdatedVoucher.Image = Global.SimpleAccounts.My.Resources.Resources.print
        Me.btnPrintUpdatedVoucher.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.btnPrintUpdatedVoucher.Name = "btnPrintUpdatedVoucher"
        Me.btnPrintUpdatedVoucher.Size = New System.Drawing.Size(146, 25)
        Me.btnPrintUpdatedVoucher.Text = "Print Updated Voucher"
        Me.btnPrintUpdatedVoucher.ToolTipText = "(Ctrl+P+V)"
        '
        'toolStripSeparator
        '
        Me.toolStripSeparator.Name = "toolStripSeparator"
        Me.toolStripSeparator.Size = New System.Drawing.Size(6, 28)
        '
        'btnHistoryLoadAll
        '
        Me.btnHistoryLoadAll.Image = Global.SimpleAccounts.My.Resources.Resources.sendcontactdetails
        Me.btnHistoryLoadAll.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.btnHistoryLoadAll.Name = "btnHistoryLoadAll"
        Me.btnHistoryLoadAll.Size = New System.Drawing.Size(70, 25)
        Me.btnHistoryLoadAll.Text = "Load All"
        Me.btnHistoryLoadAll.ToolTipText = "(Ctrl+L)"
        '
        'btnHistorySearch
        '
        Me.btnHistorySearch.Image = Global.SimpleAccounts.My.Resources.Resources.search_32
        Me.btnHistorySearch.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.btnHistorySearch.Name = "btnHistorySearch"
        Me.btnHistorySearch.Size = New System.Drawing.Size(62, 25)
        Me.btnHistorySearch.Text = "Search"
        Me.btnHistorySearch.ToolTipText = "(Ctrl+F)"
        '
        'ToolStripSeparator5
        '
        Me.ToolStripSeparator5.Name = "ToolStripSeparator5"
        Me.ToolStripSeparator5.Size = New System.Drawing.Size(6, 28)
        '
        'btnReminder1
        '
        Me.btnReminder1.Image = Global.SimpleAccounts.My.Resources.Resources.bell_icon
        Me.btnReminder1.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.btnReminder1.Name = "btnReminder1"
        Me.btnReminder1.Size = New System.Drawing.Size(78, 25)
        Me.btnReminder1.Text = "Reminder"
        Me.btnReminder1.ToolTipText = "(Ctrl+R)"
        '
        'Btn_SaveAttachment
        '
        Me.Btn_SaveAttachment.Image = Global.SimpleAccounts.My.Resources.Resources.BtnSave_Image
        Me.Btn_SaveAttachment.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.Btn_SaveAttachment.Name = "Btn_SaveAttachment"
        Me.Btn_SaveAttachment.Size = New System.Drawing.Size(123, 25)
        Me.Btn_SaveAttachment.Text = "Save Attachement"
        Me.Btn_SaveAttachment.ToolTipText = "(Ctrl+F6)"
        '
        'ToolStripSeparator4
        '
        Me.ToolStripSeparator4.Name = "ToolStripSeparator4"
        Me.ToolStripSeparator4.Size = New System.Drawing.Size(6, 28)
        '
        'HelpToolStripButton1
        '
        Me.HelpToolStripButton1.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.HelpToolStripButton1.Name = "HelpToolStripButton1"
        Me.HelpToolStripButton1.Size = New System.Drawing.Size(36, 25)
        Me.HelpToolStripButton1.Text = "He&lp"
        Me.HelpToolStripButton1.Visible = False
        '
        'btnGetAllRecord
        '
        Me.btnGetAllRecord.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.btnGetAllRecord.Name = "btnGetAllRecord"
        Me.btnGetAllRecord.Size = New System.Drawing.Size(86, 25)
        Me.btnGetAllRecord.Text = "Get All Record"
        Me.btnGetAllRecord.Visible = False
        '
        'SplitContainer1
        '
        Me.SplitContainer1.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.SplitContainer1.FixedPanel = System.Windows.Forms.FixedPanel.Panel1
        Me.SplitContainer1.IsSplitterFixed = True
        Me.SplitContainer1.Location = New System.Drawing.Point(0, 31)
        Me.SplitContainer1.Name = "SplitContainer1"
        Me.SplitContainer1.Orientation = System.Windows.Forms.Orientation.Horizontal
        '
        'SplitContainer1.Panel1
        '
        Me.SplitContainer1.Panel1.AutoScroll = True
        Me.SplitContainer1.Panel1.Controls.Add(Me.GroupBox2)
        '
        'SplitContainer1.Panel2
        '
        Me.SplitContainer1.Panel2.Controls.Add(Me.grdVouchers)
        Me.SplitContainer1.Size = New System.Drawing.Size(1282, 637)
        Me.SplitContainer1.SplitterDistance = 150
        Me.SplitContainer1.TabIndex = 2
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.Search)
        Me.GroupBox2.Controls.Add(Me.dtpSearchChequeDate)
        Me.GroupBox2.Controls.Add(Me.Label27)
        Me.GroupBox2.Controls.Add(Me.Label26)
        Me.GroupBox2.Controls.Add(Me.txtFromAmount)
        Me.GroupBox2.Controls.Add(Me.Label25)
        Me.GroupBox2.Controls.Add(Me.txtToAmount)
        Me.GroupBox2.Controls.Add(Me.Label24)
        Me.GroupBox2.Controls.Add(Me.txtSearchChequeNo)
        Me.GroupBox2.Controls.Add(Me.Label23)
        Me.GroupBox2.Controls.Add(Me.txtSearchComments)
        Me.GroupBox2.Controls.Add(Me.Label22)
        Me.GroupBox2.Controls.Add(Me.txtSearchVoucherNo)
        Me.GroupBox2.Controls.Add(Me.Label21)
        Me.GroupBox2.Controls.Add(Me.cmbSearchAccount)
        Me.GroupBox2.Controls.Add(Me.Label20)
        Me.GroupBox2.Controls.Add(Me.dtpFrom)
        Me.GroupBox2.Controls.Add(Me.Label19)
        Me.GroupBox2.Controls.Add(Me.dtpTo)
        Me.GroupBox2.Controls.Add(Me.Label18)
        Me.GroupBox2.Controls.Add(Me.cmbSearchVoucherType)
        Me.GroupBox2.Location = New System.Drawing.Point(3, 3)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(773, 134)
        Me.GroupBox2.TabIndex = 0
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Voucher Search"
        '
        'Search
        '
        Me.Search.Location = New System.Drawing.Point(543, 102)
        Me.Search.Name = "Search"
        Me.Search.Size = New System.Drawing.Size(75, 23)
        Me.Search.TabIndex = 20
        Me.Search.Text = "Search"
        Me.ToolTip1.SetToolTip(Me.Search, "Search")
        Me.Search.UseVisualStyleBackColor = True
        '
        'dtpSearchChequeDate
        '
        Me.dtpSearchChequeDate.Checked = False
        Me.dtpSearchChequeDate.CustomFormat = "dd/MMM/yyyy"
        Me.dtpSearchChequeDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.dtpSearchChequeDate.Location = New System.Drawing.Point(318, 51)
        Me.dtpSearchChequeDate.Name = "dtpSearchChequeDate"
        Me.dtpSearchChequeDate.ShowCheckBox = True
        Me.dtpSearchChequeDate.Size = New System.Drawing.Size(120, 21)
        Me.dtpSearchChequeDate.TabIndex = 11
        Me.ToolTip1.SetToolTip(Me.dtpSearchChequeDate, "Cheque Date")
        '
        'Label27
        '
        Me.Label27.AutoSize = True
        Me.Label27.Location = New System.Drawing.Point(227, 55)
        Me.Label27.Name = "Label27"
        Me.Label27.Size = New System.Drawing.Size(82, 13)
        Me.Label27.TabIndex = 10
        Me.Label27.Text = "Cheque Date"
        '
        'Label26
        '
        Me.Label26.AutoSize = True
        Me.Label26.Location = New System.Drawing.Point(227, 105)
        Me.Label26.Name = "Label26"
        Me.Label26.Size = New System.Drawing.Size(112, 13)
        Me.Label26.TabIndex = 14
        Me.Label26.Text = "Less Than Amount"
        '
        'txtFromAmount
        '
        Me.txtFromAmount.Location = New System.Drawing.Point(359, 77)
        Me.txtFromAmount.Name = "txtFromAmount"
        Me.txtFromAmount.Size = New System.Drawing.Size(79, 21)
        Me.txtFromAmount.TabIndex = 13
        Me.ToolTip1.SetToolTip(Me.txtFromAmount, "Larger Than Amount")
        '
        'Label25
        '
        Me.Label25.AutoSize = True
        Me.Label25.Location = New System.Drawing.Point(227, 80)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(124, 13)
        Me.Label25.TabIndex = 12
        Me.Label25.Text = "Larger Than Amount"
        '
        'txtToAmount
        '
        Me.txtToAmount.Location = New System.Drawing.Point(359, 102)
        Me.txtToAmount.Name = "txtToAmount"
        Me.txtToAmount.Size = New System.Drawing.Size(79, 21)
        Me.txtToAmount.TabIndex = 15
        Me.ToolTip1.SetToolTip(Me.txtToAmount, "Less Than Amount")
        '
        'Label24
        '
        Me.Label24.AutoSize = True
        Me.Label24.Location = New System.Drawing.Point(227, 27)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(70, 13)
        Me.Label24.TabIndex = 8
        Me.Label24.Text = "Cheque No"
        '
        'txtSearchChequeNo
        '
        Me.txtSearchChequeNo.Location = New System.Drawing.Point(318, 24)
        Me.txtSearchChequeNo.Name = "txtSearchChequeNo"
        Me.txtSearchChequeNo.Size = New System.Drawing.Size(120, 21)
        Me.txtSearchChequeNo.TabIndex = 9
        Me.ToolTip1.SetToolTip(Me.txtSearchChequeNo, "Cheque No")
        '
        'Label23
        '
        Me.Label23.AutoSize = True
        Me.Label23.Location = New System.Drawing.Point(457, 81)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(69, 13)
        Me.Label23.TabIndex = 18
        Me.Label23.Text = "Comments"
        '
        'txtSearchComments
        '
        Me.txtSearchComments.Location = New System.Drawing.Point(543, 78)
        Me.txtSearchComments.Name = "txtSearchComments"
        Me.txtSearchComments.Size = New System.Drawing.Size(220, 21)
        Me.txtSearchComments.TabIndex = 19
        Me.ToolTip1.SetToolTip(Me.txtSearchComments, "Comments")
        '
        'Label22
        '
        Me.Label22.AutoSize = True
        Me.Label22.Location = New System.Drawing.Point(11, 104)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(72, 13)
        Me.Label22.TabIndex = 6
        Me.Label22.Text = "Voucher No"
        '
        'txtSearchVoucherNo
        '
        Me.txtSearchVoucherNo.Location = New System.Drawing.Point(101, 101)
        Me.txtSearchVoucherNo.Name = "txtSearchVoucherNo"
        Me.txtSearchVoucherNo.Size = New System.Drawing.Size(120, 21)
        Me.txtSearchVoucherNo.TabIndex = 7
        Me.ToolTip1.SetToolTip(Me.txtSearchVoucherNo, "Voucher No")
        '
        'Label21
        '
        Me.Label21.AutoSize = True
        Me.Label21.Location = New System.Drawing.Point(457, 54)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(80, 13)
        Me.Label21.TabIndex = 16
        Me.Label21.Text = "Account Title"
        '
        'cmbSearchAccount
        '
        Appearance1.BackColor = System.Drawing.SystemColors.Info
        Me.cmbSearchAccount.Appearance = Appearance1
        Me.cmbSearchAccount.CheckedListSettings.CheckStateMember = ""
        Appearance2.BackColor = System.Drawing.Color.White
        Me.cmbSearchAccount.DisplayLayout.Appearance = Appearance2
        UltraGridColumn1.Header.VisiblePosition = 0
        UltraGridColumn1.Hidden = True
        UltraGridColumn2.Header.VisiblePosition = 1
        UltraGridColumn2.Width = 141
        UltraGridColumn3.Header.VisiblePosition = 2
        UltraGridColumn4.Header.VisiblePosition = 3
        UltraGridColumn5.Header.VisiblePosition = 4
        UltraGridColumn6.Header.VisiblePosition = 5
        UltraGridColumn6.Hidden = True
        UltraGridBand1.Columns.AddRange(New Object() {UltraGridColumn1, UltraGridColumn2, UltraGridColumn3, UltraGridColumn4, UltraGridColumn5, UltraGridColumn6})
        Me.cmbSearchAccount.DisplayLayout.BandsSerializer.Add(UltraGridBand1)
        Me.cmbSearchAccount.DisplayLayout.Override.AllowAddNew = Infragistics.Win.UltraWinGrid.AllowAddNew.No
        Me.cmbSearchAccount.DisplayLayout.Override.AllowDelete = Infragistics.Win.DefaultableBoolean.[False]
        Me.cmbSearchAccount.DisplayLayout.Override.AllowUpdate = Infragistics.Win.DefaultableBoolean.[False]
        Me.cmbSearchAccount.DisplayLayout.Override.BorderStyleCell = Infragistics.Win.UIElementBorderStyle.None
        Appearance3.BackColor = System.Drawing.Color.Transparent
        Me.cmbSearchAccount.DisplayLayout.Override.CardAreaAppearance = Appearance3
        Me.cmbSearchAccount.DisplayLayout.Override.CellClickAction = Infragistics.Win.UltraWinGrid.CellClickAction.RowSelect
        Me.cmbSearchAccount.DisplayLayout.Override.CellPadding = 3
        Me.cmbSearchAccount.DisplayLayout.Override.ColumnAutoSizeMode = Infragistics.Win.UltraWinGrid.ColumnAutoSizeMode.AllRowsInBand
        Appearance4.TextHAlignAsString = "Left"
        Me.cmbSearchAccount.DisplayLayout.Override.HeaderAppearance = Appearance4
        Me.cmbSearchAccount.DisplayLayout.Override.HeaderClickAction = Infragistics.Win.UltraWinGrid.HeaderClickAction.SortMulti
        Appearance5.BorderColor = System.Drawing.Color.LightGray
        Appearance5.TextVAlignAsString = "Middle"
        Me.cmbSearchAccount.DisplayLayout.Override.RowAppearance = Appearance5
        Appearance6.BackColor = System.Drawing.Color.LightSteelBlue
        Appearance6.BorderColor = System.Drawing.Color.Black
        Appearance6.ForeColor = System.Drawing.Color.Black
        Me.cmbSearchAccount.DisplayLayout.Override.SelectedRowAppearance = Appearance6
        Me.cmbSearchAccount.DisplayLayout.Override.SelectTypeCell = Infragistics.Win.UltraWinGrid.SelectType.None
        Me.cmbSearchAccount.DisplayLayout.Override.SelectTypeCol = Infragistics.Win.UltraWinGrid.SelectType.None
        Me.cmbSearchAccount.DisplayLayout.Override.SelectTypeRow = Infragistics.Win.UltraWinGrid.SelectType.[Single]
        Me.cmbSearchAccount.DisplayLayout.RowConnectorStyle = Infragistics.Win.UltraWinGrid.RowConnectorStyle.None
        Me.cmbSearchAccount.DisplayLayout.ScrollBounds = Infragistics.Win.UltraWinGrid.ScrollBounds.ScrollToFill
        Me.cmbSearchAccount.DisplayLayout.ScrollStyle = Infragistics.Win.UltraWinGrid.ScrollStyle.Immediate
        Me.cmbSearchAccount.DisplayLayout.TabNavigation = Infragistics.Win.UltraWinGrid.TabNavigation.NextControl
        Me.cmbSearchAccount.DisplayLayout.ViewStyle = Infragistics.Win.UltraWinGrid.ViewStyle.SingleBand
        Me.cmbSearchAccount.LimitToList = True
        Me.cmbSearchAccount.Location = New System.Drawing.Point(543, 50)
        Me.cmbSearchAccount.Name = "cmbSearchAccount"
        Me.cmbSearchAccount.Size = New System.Drawing.Size(220, 23)
        Me.cmbSearchAccount.TabIndex = 17
        Me.ToolTip1.SetToolTip(Me.cmbSearchAccount, "Select Any Account")
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.Location = New System.Drawing.Point(11, 77)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(84, 13)
        Me.Label20.TabIndex = 4
        Me.Label20.Text = "Voucher Type"
        '
        'dtpFrom
        '
        Me.dtpFrom.Checked = False
        Me.dtpFrom.CustomFormat = "dd/MMM/yyyy"
        Me.dtpFrom.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.dtpFrom.Location = New System.Drawing.Point(102, 20)
        Me.dtpFrom.Name = "dtpFrom"
        Me.dtpFrom.ShowCheckBox = True
        Me.dtpFrom.Size = New System.Drawing.Size(120, 21)
        Me.dtpFrom.TabIndex = 1
        Me.ToolTip1.SetToolTip(Me.dtpFrom, "From Date")
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.Location = New System.Drawing.Point(11, 50)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(51, 13)
        Me.Label19.TabIndex = 2
        Me.Label19.Text = "Date To"
        '
        'dtpTo
        '
        Me.dtpTo.Checked = False
        Me.dtpTo.CustomFormat = "dd/MMM/yyyy"
        Me.dtpTo.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.dtpTo.Location = New System.Drawing.Point(101, 46)
        Me.dtpTo.Name = "dtpTo"
        Me.dtpTo.ShowCheckBox = True
        Me.dtpTo.Size = New System.Drawing.Size(120, 21)
        Me.dtpTo.TabIndex = 3
        Me.ToolTip1.SetToolTip(Me.dtpTo, "To Date")
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Location = New System.Drawing.Point(11, 24)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(67, 13)
        Me.Label18.TabIndex = 0
        Me.Label18.Text = "Date From"
        '
        'cmbSearchVoucherType
        '
        Me.cmbSearchVoucherType.FormattingEnabled = True
        Me.cmbSearchVoucherType.Location = New System.Drawing.Point(101, 74)
        Me.cmbSearchVoucherType.Name = "cmbSearchVoucherType"
        Me.cmbSearchVoucherType.Size = New System.Drawing.Size(121, 21)
        Me.cmbSearchVoucherType.TabIndex = 5
        Me.ToolTip1.SetToolTip(Me.cmbSearchVoucherType, "Voucher Type")
        '
        'UltraTabControl1
        '
        Me.UltraTabControl1.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.UltraTabControl1.Controls.Add(Me.UltraTabSharedControlsPage1)
        Me.UltraTabControl1.Controls.Add(Me.UltraTabPageControl1)
        Me.UltraTabControl1.Controls.Add(Me.grdVoucher)
        Me.UltraTabControl1.Location = New System.Drawing.Point(0, 0)
        Me.UltraTabControl1.Name = "UltraTabControl1"
        Me.UltraTabControl1.SharedControlsPage = Me.UltraTabSharedControlsPage1
        Me.UltraTabControl1.Size = New System.Drawing.Size(1284, 689)
        Me.UltraTabControl1.Style = Infragistics.Win.UltraWinTabControl.UltraTabControlStyle.Excel
        Me.UltraTabControl1.TabIndex = 0
        Me.UltraTabControl1.TabOrientation = Infragistics.Win.UltraWinTabs.TabOrientation.BottomLeft
        UltraTab1.TabPage = Me.UltraTabPageControl1
        UltraTab1.Text = "Payment"
        UltraTab2.TabPage = Me.grdVoucher
        UltraTab2.Text = "History"
        Me.UltraTabControl1.Tabs.AddRange(New Infragistics.Win.UltraWinTabControl.UltraTab() {UltraTab1, UltraTab2})
        Me.UltraTabControl1.ViewStyle = Infragistics.Win.UltraWinTabControl.ViewStyle.Office2007
        '
        'UltraTabSharedControlsPage1
        '
        Me.UltraTabSharedControlsPage1.Location = New System.Drawing.Point(-10000, -10000)
        Me.UltraTabSharedControlsPage1.Name = "UltraTabSharedControlsPage1"
        Me.UltraTabSharedControlsPage1.Size = New System.Drawing.Size(1282, 668)
        '
        'BackgroundWorker1
        '
        '
        'BackgroundWorker2
        '
        '
        'OpenFileDialog1
        '
        Me.OpenFileDialog1.FileName = "OpenFileDialog1"
        Me.OpenFileDialog1.Multiselect = True
        Me.OpenFileDialog1.ShowHelp = True
        Me.OpenFileDialog1.SupportMultiDottedExtensions = True
        Me.OpenFileDialog1.Title = "Images"
        '
        'frmPaymentNew
        '
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None
        Me.BackColor = System.Drawing.SystemColors.Menu
        Me.ClientSize = New System.Drawing.Size(1276, 689)
        Me.Controls.Add(Me.UltraTabControl1)
        Me.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.KeyPreview = True
        Me.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.Name = "frmPaymentNew"
        Me.Text = "Payments"
        Me.UltraTabPageControl1.ResumeLayout(False)
        Me.UltraTabPageControl1.PerformLayout()
        CType(Me.grd, System.ComponentModel.ISupportInitialize).EndInit()
        Me.pnlGrd.ResumeLayout(False)
        Me.pnlDetail.ResumeLayout(False)
        Me.pnlHeader.ResumeLayout(False)
        Me.pnlHeader.PerformLayout()
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        CType(Me.txtMemo, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel2.ResumeLayout(False)
        Me.Panel2.PerformLayout()
        CType(Me.cmbInvoice, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.cmbAccounts, System.ComponentModel.ISupportInitialize).EndInit()
        Me.FlowLayoutPanel1.ResumeLayout(False)
        Me.pnlBank.ResumeLayout(False)
        Me.pnlBank.PerformLayout()
        Me.pnlCost.ResumeLayout(False)
        Me.pnlCost.PerformLayout()
        CType(Me.txtReference, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ToolStrip1.ResumeLayout(False)
        Me.ToolStrip1.PerformLayout()
        Me.grdVoucher.ResumeLayout(False)
        CType(Me.grdVouchers, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ToolStrip2.ResumeLayout(False)
        Me.ToolStrip2.PerformLayout()
        Me.SplitContainer1.Panel1.ResumeLayout(False)
        Me.SplitContainer1.Panel2.ResumeLayout(False)
        CType(Me.SplitContainer1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.SplitContainer1.ResumeLayout(False)
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        CType(Me.cmbSearchAccount, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.UltraTabControl1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.UltraTabControl1.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents dtVoucherDate As System.Windows.Forms.DateTimePicker
    Friend WithEvents txtAmount As System.Windows.Forms.TextBox
    Friend WithEvents cmbVoucherType As System.Windows.Forms.ComboBox
    Friend WithEvents lblDocDate As System.Windows.Forms.Label
    Friend WithEvents lblHeader As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents cmbAccounts As Infragistics.Win.UltraWinGrid.UltraCombo
    Friend WithEvents btnAdd As System.Windows.Forms.Button
    Friend WithEvents UltraTabControl1 As Infragistics.Win.UltraWinTabControl.UltraTabControl
    Friend WithEvents UltraTabSharedControlsPage1 As Infragistics.Win.UltraWinTabControl.UltraTabSharedControlsPage
    Friend WithEvents UltraTabPageControl1 As Infragistics.Win.UltraWinTabControl.UltraTabPageControl
    Friend WithEvents grdVoucher As Infragistics.Win.UltraWinTabControl.UltraTabPageControl
    Friend WithEvents chkPost As System.Windows.Forms.CheckBox
    Friend WithEvents BackgroundWorker1 As System.ComponentModel.BackgroundWorker
    Friend WithEvents SplitContainer1 As System.Windows.Forms.SplitContainer
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents Label20 As System.Windows.Forms.Label
    Friend WithEvents dtpFrom As System.Windows.Forms.DateTimePicker
    Friend WithEvents Label19 As System.Windows.Forms.Label
    Friend WithEvents dtpTo As System.Windows.Forms.DateTimePicker
    Friend WithEvents Label18 As System.Windows.Forms.Label
    Friend WithEvents cmbSearchVoucherType As System.Windows.Forms.ComboBox
    Friend WithEvents Label21 As System.Windows.Forms.Label
    Friend WithEvents cmbSearchAccount As Infragistics.Win.UltraWinGrid.UltraCombo
    Friend WithEvents Label22 As System.Windows.Forms.Label
    Friend WithEvents txtSearchVoucherNo As System.Windows.Forms.TextBox
    Friend WithEvents txtSearchComments As System.Windows.Forms.TextBox
    Friend WithEvents Label23 As System.Windows.Forms.Label
    Friend WithEvents txtSearchChequeNo As System.Windows.Forms.TextBox
    Friend WithEvents Label24 As System.Windows.Forms.Label
    Friend WithEvents Label26 As System.Windows.Forms.Label
    Friend WithEvents txtFromAmount As System.Windows.Forms.TextBox
    Friend WithEvents Label25 As System.Windows.Forms.Label
    Friend WithEvents txtToAmount As System.Windows.Forms.TextBox
    Friend WithEvents dtpSearchChequeDate As System.Windows.Forms.DateTimePicker
    Friend WithEvents Label27 As System.Windows.Forms.Label
    Friend WithEvents Search As System.Windows.Forms.Button
    Friend WithEvents ToolTip1 As System.Windows.Forms.ToolTip
    Friend WithEvents BackgroundWorker2 As System.ComponentModel.BackgroundWorker
    Friend WithEvents lblPrintStatus As System.Windows.Forms.Label
    Friend WithEvents txtDiscount As System.Windows.Forms.TextBox
    Friend WithEvents Label29 As System.Windows.Forms.Label
    Friend WithEvents lblSaleman As System.Windows.Forms.Label
    Friend WithEvents cmbSaleman As System.Windows.Forms.ComboBox
    Friend WithEvents chkChecked As System.Windows.Forms.CheckBox
    Friend WithEvents OpenFileDialog1 As System.Windows.Forms.OpenFileDialog
    Friend WithEvents cmbCompany As System.Windows.Forms.ComboBox
    Friend WithEvents lblCompany As System.Windows.Forms.Label
    Friend WithEvents lblCurrency As System.Windows.Forms.Label
    Friend WithEvents cmbCurrency As System.Windows.Forms.ComboBox
    Friend WithEvents lblPayMethod As System.Windows.Forms.Label
    Friend WithEvents lblRecieveIn As System.Windows.Forms.Label
    Friend WithEvents cmbSalesTax As System.Windows.Forms.ComboBox
    Friend WithEvents lblSales As System.Windows.Forms.Label
    Friend WithEvents cmbIncomeTaxAccount As System.Windows.Forms.ComboBox
    Friend WithEvents lblIncomeTaxAccount As System.Windows.Forms.Label
    Friend WithEvents txtGrossAmount As System.Windows.Forms.TextBox
    Friend WithEvents lblGrossAmount As System.Windows.Forms.Label
    Friend WithEvents lblReference As System.Windows.Forms.Label
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents lblWH As System.Windows.Forms.Label
    Friend WithEvents lblWHTaxAmount As System.Windows.Forms.Label
    Friend WithEvents lblSalesTax As System.Windows.Forms.Label
    Friend WithEvents lblSalesTaxAmount As System.Windows.Forms.Label
    Friend WithEvents txtNetAmount As System.Windows.Forms.TextBox
    Friend WithEvents txtWithHoldingTaxAmount As System.Windows.Forms.TextBox
    Friend WithEvents txtSalesTaxAmount As System.Windows.Forms.TextBox
    Friend WithEvents txtWithHolding As System.Windows.Forms.TextBox
    Friend WithEvents txtSalesTax As System.Windows.Forms.TextBox
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents txtVoucherNo As System.Windows.Forms.TextBox
    Friend WithEvents lblVoucherNo As System.Windows.Forms.Label
    Friend WithEvents chkEnableDepositAc As System.Windows.Forms.CheckBox
    Friend WithEvents lblNetAmount As System.Windows.Forms.Label
    Friend WithEvents txtMemo As Infragistics.Win.UltraWinEditors.UltraTextEditor
    Friend WithEvents cmbCashAccount As System.Windows.Forms.ComboBox
    Friend WithEvents lblCurrencyRate As System.Windows.Forms.Label
    Friend WithEvents txtCurrencyRate As System.Windows.Forms.TextBox
    Friend WithEvents txtTax As System.Windows.Forms.TextBox
    Friend WithEvents Label30 As System.Windows.Forms.Label
    Friend WithEvents txtTaxAmount As System.Windows.Forms.TextBox
    Friend WithEvents Label31 As System.Windows.Forms.Label
    Friend WithEvents lblCostCenter As System.Windows.Forms.Label
    Friend WithEvents lblDescription As System.Windows.Forms.Label
    Friend WithEvents cmbCostCenter As System.Windows.Forms.ComboBox
    Friend WithEvents txtReference As Infragistics.Win.UltraWinEditors.UltraTextEditor
    Friend WithEvents txtDepositBeforeBalance As System.Windows.Forms.TextBox
    Friend WithEvents txtCustomerBalance As System.Windows.Forms.TextBox
    Friend WithEvents pnlBank As System.Windows.Forms.Panel
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents cmbBank As System.Windows.Forms.ComboBox
    Friend WithEvents txtChequeNo As System.Windows.Forms.TextBox
    Friend WithEvents dtChequeDate As System.Windows.Forms.DateTimePicker
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents pnlCost As System.Windows.Forms.Panel
    Friend WithEvents lblPayment As System.Windows.Forms.Label
    Friend WithEvents ToolStrip1 As System.Windows.Forms.ToolStrip
    Friend WithEvents BtnNew As System.Windows.Forms.ToolStripButton
    Friend WithEvents BtnEdit As System.Windows.Forms.ToolStripButton
    Friend WithEvents BtnSave As System.Windows.Forms.ToolStripButton
    Friend WithEvents BtnDelete As System.Windows.Forms.ToolStripButton
    Friend WithEvents BtnPrint As System.Windows.Forms.ToolStripSplitButton
    Friend WithEvents PrintReceiptToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents PrintAttachmentVoucherToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents PrintUpdatedVoucherToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents toolStripSeparator1 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents ToolStripButton1 As System.Windows.Forms.ToolStripButton
    Friend WithEvents btnUpdateTimes As System.Windows.Forms.ToolStripSplitButton
    Friend WithEvents btnReminder As System.Windows.Forms.ToolStripButton
    Friend WithEvents BtnRefresh As System.Windows.Forms.ToolStripButton
    Friend WithEvents ToolStripSeparator3 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents btnAttachment As System.Windows.Forms.ToolStripSplitButton
    Friend WithEvents btnPreviewAttachment As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator8 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents btnSMSTemplate As System.Windows.Forms.ToolStripButton
    Friend WithEvents ToolStripSeparator9 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents HelpToolStripButton As System.Windows.Forms.ToolStripButton
    Friend WithEvents ToolStripSeparator2 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents CtrlGrdBar1 As SimpleAccounts.CtrlGrdBar
    Friend WithEvents ToolStrip2 As System.Windows.Forms.ToolStrip
    Friend WithEvents btnHisotryEdit As System.Windows.Forms.ToolStripButton
    Friend WithEvents ToolStripSeparator6 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents btnSearchDelete As System.Windows.Forms.ToolStripButton
    Friend WithEvents ToolStripSeparator7 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents btnHistoryPrint As System.Windows.Forms.ToolStripSplitButton
    Friend WithEvents PrintReceiptToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents PrintSelectedVouchersToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents PrintAttachmentVoucherToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator10 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents btnPrintUpdatedVoucher As System.Windows.Forms.ToolStripButton
    Friend WithEvents toolStripSeparator As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents btnHistoryLoadAll As System.Windows.Forms.ToolStripButton
    Friend WithEvents btnHistorySearch As System.Windows.Forms.ToolStripButton
    Friend WithEvents ToolStripSeparator5 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents btnReminder1 As System.Windows.Forms.ToolStripButton
    Friend WithEvents Btn_SaveAttachment As System.Windows.Forms.ToolStripButton
    Friend WithEvents ToolStripSeparator4 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents HelpToolStripButton1 As System.Windows.Forms.ToolStripButton
    Friend WithEvents btnGetAllRecord As System.Windows.Forms.ToolStripButton
    Friend WithEvents CtrlGrdBar2 As SimpleAccounts.CtrlGrdBar
    Friend WithEvents btnBackToOldReciept As System.Windows.Forms.ToolStripButton
    Friend WithEvents grdVouchers As Janus.Windows.GridEX.GridEX
    Friend WithEvents CtrlGrdBar4 As SimpleAccounts.CtrlGrdBar
    Friend WithEvents ToolStripSeparator11 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents CtrlGrdBar10 As SimpleAccounts.CtrlGrdBar
    'Friend WithEvents lblProgress As System.Windows.Forms.Label
    Friend WithEvents grd As Janus.Windows.GridEX.GridEX
    Friend WithEvents pnlDetail As System.Windows.Forms.Panel
    Friend WithEvents pnlGrd As System.Windows.Forms.Panel
    Friend WithEvents TaxConfiguration As System.Windows.Forms.ToolStripButton
    Friend WithEvents ToolStripSeparator12 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents ToolStripSeparator14 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents FlowLayoutPanel1 As System.Windows.Forms.FlowLayoutPanel
    Friend WithEvents Label36 As System.Windows.Forms.Label
    Friend WithEvents cmbChequeBook As System.Windows.Forms.ComboBox
    Friend WithEvents cmbLayout As System.Windows.Forms.ToolStripComboBox
    Friend WithEvents lblPostedBy As System.Windows.Forms.Label
    Friend WithEvents lblCheckedBy As System.Windows.Forms.Label
    Friend WithEvents lblCashRequest As System.Windows.Forms.Label
    Friend WithEvents cmbCashRequest As System.Windows.Forms.ComboBox
    Friend WithEvents btnApprovalHistory As System.Windows.Forms.ToolStripButton
    Friend WithEvents pnlHeader As System.Windows.Forms.Panel
    Friend WithEvents lblAmountNumberConvertor As System.Windows.Forms.Label
    Friend WithEvents lblNetAmountNumberConvertor As System.Windows.Forms.Label
    Friend WithEvents btnReplace As System.Windows.Forms.Button
    Friend WithEvents btnCancel As System.Windows.Forms.Button
    Friend WithEvents cmbInvoice As Infragistics.Win.UltraWinGrid.UltraCombo
    Friend WithEvents lblInvoice As System.Windows.Forms.Label
    Friend WithEvents btnPurchaseInvoiceSearch As System.Windows.Forms.ToolStripButton
    Friend WithEvents chkAllAccounts As System.Windows.Forms.CheckBox
    Friend WithEvents lblProgress As System.Windows.Forms.Label
    'Friend WithEvents Panel3 As System.Windows.Forms.Panel
End Class
